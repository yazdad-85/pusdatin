<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    protected $fillable = [
        'nama', 'nis', 'nisn', 'jenis_kelamin', 'tempat_lahir', 'tanggal_lahir', 'agama', 'alamat', 'telepon', 'foto',
        'nama_ayah', 'pekerjaan_ayah', 'pendidikan_ayah', 'nama_ibu', 'pekerjaan_ibu', 'pendidikan_ibu',
        'nama_wali', 'pekerjaan_wali', 'telepon_wali', 'penghasilan',
        'jenjang', 'tingkat', 'kelas', 'tahun_masuk', 'status', 'asal_sekolah', 'jurusan',
        'riwayat_pendidikan', 'riwayat_pendidikan_sebelumnya', 'prestasi', 'lulus_ke',
        'akta_kelahiran', 'kartu_keluarga', 'kartu_kip', 'ijazah', 'surat_pindah',
        'beasiswa', 'jenis_beasiswa', 'periode_beasiswa', 'keterangan_beasiswa',
        'institution_id', 'academic_year_id'
    ];

    public function institution()
    {
        return $this->belongsTo(\App\Institution::class);
    }

    public function academicYear()
    {
        return $this->belongsTo(\App\AcademicYear::class);
    }
}
