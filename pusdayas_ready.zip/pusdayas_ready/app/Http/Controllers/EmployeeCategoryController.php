<?php
namespace App\Http\Controllers;
use App\EmployeeCategory;
use Illuminate\Http\Request;
class EmployeeCategoryController extends Controller
{
    public function index() {
        $categories = EmployeeCategory::orderBy('nama_kategori')->get();
        return view('employee_categories.index', compact('categories'));
    }
    public function create() {
        return view('employee_categories.create');
    }
    public function store(Request $request) {
        $request->validate(['nama_kategori' => 'required|unique:employee_categories,nama_kategori']);
        EmployeeCategory::create($request->only(['nama_kategori','keterangan']));
        return redirect()->route('employee-categories.index')->with('success','Kategori berhasil ditambah');
    }
    public function edit($id) {
        $category = EmployeeCategory::findOrFail($id);
        return view('employee_categories.edit', compact('category'));
    }
    public function update(Request $request, $id) {
        $category = EmployeeCategory::findOrFail($id);
        $request->validate(['nama_kategori' => 'required|unique:employee_categories,nama_kategori,'.$id]);
        $category->update($request->only(['nama_kategori','keterangan']));
        return redirect()->route('employee-categories.index')->with('success','Kategori berhasil diupdate');
    }
    public function destroy($id) {
        $category = EmployeeCategory::findOrFail($id);
        $category->delete();
        return redirect()->route('employee-categories.index')->with('success','Kategori berhasil dihapus');
    }
} 