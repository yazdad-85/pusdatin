<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTeachersTable extends Migration
{
    public function up()
    {
        Schema::create('teachers', function (Blueprint $table) {
            $table->bigIncrements('id');
            // Data Pribadi
            $table->string('nama_lengkap');
            $table->string('nik')->nullable();
            $table->string('nuptk')->nullable();
            $table->string('tempat_lahir')->nullable();
            $table->date('tanggal_lahir')->nullable();
            $table->enum('jenis_kelamin', ['Laki-laki', 'Perempuan'])->nullable();
            $table->string('agama')->nullable();
            $table->text('alamat')->nullable();
            $table->string('status_pernikahan')->nullable();
            $table->string('telepon')->nullable();
            $table->enum('status', ['Aktif', 'Non Aktif'])->default('Aktif');
            $table->string('email')->nullable();
            $table->string('foto')->nullable();
            // Data Kepegawaian
            $table->enum('status_kepegawaian', ['PNS', 'Non-PNS', 'Honorer'])->nullable();
            $table->date('tmt')->nullable();
            $table->string('sk_pengangkatan')->nullable(); // file
            $table->string('nomor_sk')->nullable();
            $table->string('instansi_pengangkat')->nullable();
            $table->string('pangkat_golongan')->nullable();
            $table->integer('gaji_pokok')->nullable();
            // Status Khusus
            $table->enum('sertifikasi_guru', ['Sudah', 'Belum'])->nullable();
            $table->string('nomor_sertifikat')->nullable();
            $table->year('tahun_sertifikasi')->nullable();
            $table->string('file_sertifikat')->nullable();
            $table->enum('inpasing', ['Ya', 'Tidak'])->nullable();
            $table->string('nomor_inpasing')->nullable();
            $table->year('tahun_inpasing')->nullable();
            $table->string('file_sk_inpasing')->nullable();
            $table->string('tunjangan_khusus')->nullable();
            // Data Akademik
            $table->string('pendidikan_terakhir')->nullable();
            $table->string('jenjang_pendidikan')->nullable();
            $table->string('nama_pt')->nullable();
            $table->string('program_studi')->nullable();
            $table->year('tahun_lulus')->nullable();
            $table->string('file_ijazah')->nullable();
            $table->text('riwayat_pendidikan')->nullable(); // opsional json/text
            $table->text('riwayat_mengajar')->nullable(); // opsional json/text
            $table->string('mapel_diampu')->nullable();
            $table->string('jenjang_mapel')->nullable();
            $table->integer('jam_mengajar')->nullable();
            // Berkas & Arsip Digital
            $table->string('file_ktp')->nullable();
            $table->string('file_kk')->nullable();
            $table->string('file_ijazah_terakhir')->nullable();
            $table->string('file_sertifikat_pelatihan')->nullable();
            $table->string('file_sk_pengangkatan')->nullable();
            $table->string('file_sk_penempatan')->nullable();
            $table->string('file_sertifikat_sertifikasi')->nullable();
            $table->string('file_berkas_lain')->nullable();
            // Relasi
            $table->unsignedBigInteger('institution_id')->nullable();
            $table->timestamps();
        });
    }
    public function down()
    {
        Schema::dropIfExists('teachers');
    }
} 