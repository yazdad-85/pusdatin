@extends('layouts.app')
@section('content')
<div class="container">
    <h2 class="mb-4">Tambah Kategori Karyawan</h2>
    <form method="POST" action="{{ route('employee-categories.store') }}">
        @csrf
        <div class="mb-3">
            <label class="form-label">Nama Kategori</label>
            <input type="text" name="nama_kategori" class="form-control @error('nama_kategori') is-invalid @enderror" value="{{ old('nama_kategori') }}" required>
            @error('nama_kategori')<div class="invalid-feedback">{{ $message }}</div>@enderror
        </div>
        <div class="mb-3">
            <label class="form-label">Keterangan (opsional)</label>
            <input type="text" name="keterangan" class="form-control" value="{{ old('keterangan') }}">
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="{{ route('employee-categories.index') }}" class="btn btn-secondary">Batal</a>
    </form>
</div>
@endsection 