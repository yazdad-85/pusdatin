<?php

use Illuminate\Database\Seeder;
use App\User;
use Illuminate\Support\Facades\Hash;

class CreateSuperAdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Cek apakah sudah ada super admin
        $existingSuperAdmin = User::where('role', 'superadmin')->first();
        
        if (!$existingSuperAdmin) {
            // Buat super admin baru
            User::create([
                'name' => 'Super Administrator',
                'email' => 'superadmin@pusdayas.com',
                'password' => Hash::make('superadmin123'),
                'role' => 'superadmin',
                'status' => 'Aktif',
                'email_verified_at' => now(),
            ]);
            
            echo "Super admin berhasil dibuat!\n";
            echo "Email: superadmin@pusdayas.com\n";
            echo "Password: superadmin123\n";
        } else {
            echo "Super admin sudah ada dengan email: " . $existingSuperAdmin->email . "\n";
        }
    }
} 