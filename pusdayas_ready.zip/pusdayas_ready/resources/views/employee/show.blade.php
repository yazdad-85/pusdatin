@extends('layouts.app')
@section('content')
<div class="container">
    <h2 class="mb-4">Detail Karyawan</h2>
    <ul class="nav nav-tabs mb-3" id="empTab" role="tablist">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#pribadi" type="button" role="tab">A. Data Pribadi</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#kategori" type="button" role="tab">B. Kategori & Jabatan</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#kepegawaian" type="button" role="tab">C. Data Kepegawaian</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#akademik" type="button" role="tab">D. Akademik & Pelatihan</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#arsip" type="button" role="tab">E. Berkas & Arsip</button></li>
    </ul>
    <div class="tab-content" id="empTabContent">
        <!-- Data Pribadi -->
        <div class="tab-pane fade show active" id="pribadi" role="tabpanel">
            <table class="table table-bordered w-100">
                <tr><th>Nama Lengkap</th><td>{{ $employee->nama_lengkap }}</td></tr>
                <tr><th>NIK</th><td>{{ $employee->nik }}</td></tr>
                <tr><th>Tempat Lahir</th><td>{{ $employee->tempat_lahir }}</td></tr>
                <tr><th>Tanggal Lahir</th><td>{{ $employee->tanggal_lahir }}</td></tr>
                <tr><th>Jenis Kelamin</th><td>{{ $employee->jenis_kelamin }}</td></tr>
                <tr><th>Agama</th><td>{{ $employee->agama }}</td></tr>
                <tr><th>Alamat</th><td>{{ $employee->alamat }}</td></tr>
                <tr><th>Nomor HP</th><td>{{ $employee->telepon }}</td></tr>
                <tr><th>Email</th><td>{{ $employee->email }}</td></tr>
                <tr><th>Status Pernikahan</th><td>{{ $employee->status_pernikahan }}</td></tr>
                <tr><th>Pendidikan Terakhir</th><td>{{ $employee->pendidikan_terakhir }}</td></tr>
                <tr><th>Foto</th><td>@if($employee->foto)<a href="{{ asset('storage/'.$employee->foto) }}" target="_blank">Lihat Foto</a>@else - @endif</td></tr>
            </table>
        </div>
        <!-- Kategori & Jabatan -->
        <div class="tab-pane fade" id="kategori" role="tabpanel">
            <table class="table table-bordered w-100">
                <tr><th>Kategori Karyawan</th><td>{{ $employee->category ? $employee->category->nama_kategori : '-' }}</td></tr>
                <tr><th>Unit Kerja / Lembaga</th><td>{{ $employee->institution ? $employee->institution->nama_lembaga : '-' }}</td></tr>
                <tr><th>Tahun Akademik</th><td>{{ $employee->academicYear ? $employee->academicYear->tahun_akademik . ' - ' . $employee->academicYear->semester : '-' }}</td></tr>
                <tr><th>Jabatan / Fungsi</th><td>{{ $employee->jabatan }}</td></tr>
                <tr><th>Keterangan Tugas Tambahan</th><td>{{ $employee->tugas_tambahan }}</td></tr>
            </table>
        </div>
        <!-- Data Kepegawaian -->
        <div class="tab-pane fade" id="kepegawaian" role="tabpanel">
            <table class="table table-bordered w-100">
                <tr><th>Status Pegawai</th><td>{{ $employee->status_pegawai }}</td></tr>
                <tr><th>Nomor SK Pengangkatan</th><td>{{ $employee->nomor_sk }}</td></tr>
                <tr><th>Tanggal Mulai Tugas (TMT)</th><td>{{ $employee->tmt }}</td></tr>
                <tr><th>Masa Kerja</th><td>{{ $employee->masa_kerja }}</td></tr>
                <tr><th>Jenis Kontrak</th><td>{{ $employee->jenis_kontrak }}</td></tr>
                <tr><th>Status</th><td>{{ $employee->status }}</td></tr>
                <tr><th>Keterangan Pensiun / Berhenti</th><td>{{ $employee->keterangan_pensiun }}</td></tr>
            </table>
        </div>
        <!-- Akademik & Pelatihan -->
        <div class="tab-pane fade" id="akademik" role="tabpanel">
            <table class="table table-bordered w-100">
                <tr><th>Pendidikan Terakhir (Jenjang)</th><td>{{ $employee->jenjang_pendidikan }}</td></tr>
                <tr><th>Nama Sekolah/PT</th><td>{{ $employee->nama_pt }}</td></tr>
                <tr><th>Tahun Lulus</th><td>{{ $employee->tahun_lulus }}</td></tr>
                <tr><th>Ijazah</th><td>@if($employee->file_ijazah)<a href="{{ asset('storage/'.$employee->file_ijazah) }}" target="_blank">Download</a>@else - @endif</td></tr>
            </table>
            <h5 class="mt-3">Riwayat Pelatihan</h5>
            <table class="table table-bordered">
                <thead><tr><th>Nama Pelatihan</th><th>Tahun</th><th>Sertifikat</th></tr></thead>
                <tbody>
                @if(is_array($employee->riwayat_pelatihan))
                    @foreach($employee->riwayat_pelatihan as $p)
                    <tr>
                        <td>{{ $p['nama'] ?? '-' }}</td>
                        <td>{{ $p['tahun'] ?? '-' }}</td>
                        <td>@if(!empty($p['file']))<a href="{{ asset('storage/'.$p['file']) }}" target="_blank">Download</a>@else - @endif</td>
                    </tr>
                    @endforeach
                @else
                    <tr><td colspan="3" class="text-center">-</td></tr>
                @endif
                </tbody>
            </table>
        </div>
        <!-- Berkas & Arsip Digital -->
        <div class="tab-pane fade" id="arsip" role="tabpanel">
            <table class="table table-bordered w-100">
                <tr><th>KTP</th><td>@if($employee->file_ktp)<a href="{{ asset('storage/'.$employee->file_ktp) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>KK</th><td>@if($employee->file_kk)<a href="{{ asset('storage/'.$employee->file_kk) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>Ijazah Terakhir</th><td>@if($employee->file_ijazah_terakhir)<a href="{{ asset('storage/'.$employee->file_ijazah_terakhir) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>SK Pengangkatan</th><td>@if($employee->file_sk_pengangkatan)<a href="{{ asset('storage/'.$employee->file_sk_pengangkatan) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>SK Penugasan</th><td>@if($employee->file_sk_penugasan)<a href="{{ asset('storage/'.$employee->file_sk_penugasan) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>Sertifikat Pelatihan</th><td>@if($employee->file_sertifikat_pelatihan)<a href="{{ asset('storage/'.$employee->file_sertifikat_pelatihan) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>Surat Perjanjian Kerja</th><td>@if($employee->file_perjanjian_kerja)<a href="{{ asset('storage/'.$employee->file_perjanjian_kerja) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>Dokumen Tambahan</th><td>@if($employee->file_dokumen_tambahan)<a href="{{ asset('storage/'.$employee->file_dokumen_tambahan) }}" target="_blank">Download</a>@else - @endif</td></tr>
            </table>
        </div>
    </div>
    <a href="{{ route('employee') }}" class="btn btn-secondary btn-sm mt-3">Kembali</a>
</div>
@endsection 