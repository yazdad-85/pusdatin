@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Upload Arsip Digital</h1>
    <p>Halaman ini akan digunakan untuk upload file arsip digital.</p>
</div>
@endsection