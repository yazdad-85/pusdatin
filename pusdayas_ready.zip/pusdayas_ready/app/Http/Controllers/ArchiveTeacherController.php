<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ArchiveTeacherController extends Controller
{
    public function index()
    {
        return view('archives.teachers');
    }
}
