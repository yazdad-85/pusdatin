<?php

namespace App\Http\Controllers;

use App\AcademicYear;
use Illuminate\Http\Request;

class AcademicYearController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $academicYears = AcademicYear::orderBy('tahun_akademik', 'desc')
                                    ->orderBy('semester', 'desc')
                                    ->paginate(10);
        
        return view('academic_year.index', compact('academicYears'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('academic_year.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'tahun_akademik' => 'required|string|max:255',
            'semester' => 'required|in:Ganjil,Genap',
            'tanggal_mulai' => 'required|date',
            'tanggal_selesai' => 'required|date|after:tanggal_mulai',
            'status' => 'required|in:aktif,nonaktif',
            'keterangan' => 'nullable|string'
        ]);

        // Jika status aktif, nonaktifkan yang lain
        if ($request->status === 'aktif') {
            AcademicYear::where('status', 'aktif')->update(['status' => 'nonaktif']);
        }

        AcademicYear::create($request->all());

        return redirect()->route('academic-year.index')
                        ->with('success', 'Tahun Akademik berhasil ditambahkan!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AcademicYear  $academicYear
     * @return \Illuminate\Http\Response
     */
    public function show(AcademicYear $academicYear)
    {
        return view('academic_year.show', compact('academicYear'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AcademicYear  $academicYear
     * @return \Illuminate\Http\Response
     */
    public function edit(AcademicYear $academicYear)
    {
        return view('academic_year.edit', compact('academicYear'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AcademicYear  $academicYear
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AcademicYear $academicYear)
    {
        $request->validate([
            'tahun_akademik' => 'required|string|max:255',
            'semester' => 'required|in:Ganjil,Genap',
            'tanggal_mulai' => 'required|date',
            'tanggal_selesai' => 'required|date|after:tanggal_mulai',
            'status' => 'required|in:aktif,nonaktif',
            'keterangan' => 'nullable|string'
        ]);

        // Jika status aktif, nonaktifkan yang lain
        if ($request->status === 'aktif') {
            AcademicYear::where('id', '!=', $academicYear->id)
                       ->where('status', 'aktif')
                       ->update(['status' => 'nonaktif']);
        }

        $academicYear->update($request->all());

        return redirect()->route('academic-year.index')
                        ->with('success', 'Tahun Akademik berhasil diperbarui!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AcademicYear  $academicYear
     * @return \Illuminate\Http\Response
     */
    public function destroy(AcademicYear $academicYear)
    {
        // Cek apakah ada data yang terkait
        $studentCount = $academicYear->students()->count();
        $teacherCount = $academicYear->teachers()->count();
        $employeeCount = $academicYear->employees()->count();

        if ($studentCount > 0 || $teacherCount > 0 || $employeeCount > 0) {
            return redirect()->route('academic-year.index')
                            ->with('error', 'Tahun Akademik tidak dapat dihapus karena masih terkait dengan data Siswa, Guru, atau Karyawan!');
        }

        $academicYear->delete();

        return redirect()->route('academic-year.index')
                        ->with('success', 'Tahun Akademik berhasil dihapus!');
    }
}
