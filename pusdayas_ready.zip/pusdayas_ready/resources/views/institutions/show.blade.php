@extends('layouts.app')
@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap">
        <h2 class="mb-0" style="font-size:1.4rem; font-weight:600;">Detail Lembaga</h2>
        <a href="{{ route('institutions.index') }}" class="btn btn-secondary btn-sm mt-2 mt-md-0">Kembali</a>
    </div>
    <div class="card shadow-sm">
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-8">
                    <table class="table table-borderless">
                        <tr><th>Nama Lembaga</th><td>{{ $institution->nama_lembaga }}</td></tr>
                        <tr><th>NPSN</th><td>{{ $institution->npsn }}</td></tr>
                        <tr><th>Jenis Lembaga</th><td>{{ $institution->jenis_lembaga }}</td></tr>
                        <tr><th>Alamat</th><td>{{ $institution->alamat }}</td></tr>
                        <tr><th>Telepon</th><td>{{ $institution->telepon }}</td></tr>
                        <tr><th>Email</th><td>{{ $institution->email }}</td></tr>
                        <tr><th>Kepala Lembaga</th><td>{{ $institution->kepala_lembaga }}</td></tr>
                    </table>
                </div>
                <div class="col-md-4 text-center">
                    @if($institution->logo)
                        <img src="/{{ $institution->logo }}" alt="Logo Lembaga" style="max-width:120px; max-height:120px; border-radius:8px; box-shadow:0 2px 8px rgba(44,62,80,0.08);">
                    @else
                        <div class="text-muted">Tidak ada logo</div>
                    @endif
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
      <div class="col-md-12">
        <h5 class="mb-2">Siswa di Lembaga Ini</h5>
        <div class="table-responsive mb-4">
          <table class="table table-sm table-hover align-middle">
            <thead class="table-light">
              <tr><th>No</th><th>Nama</th><th>NISN</th><th>Kelas</th><th>Telepon</th></tr>
            </thead>
            <tbody>
              @forelse($institution->students as $student)
              <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $student->nama }}</td>
                <td>{{ $student->nisn }}</td>
                <td>{{ $student->kelas }}</td>
                <td>{{ $student->telepon }}</td>
              </tr>
              @empty
              <tr><td colspan="5" class="text-center">Tidak ada siswa.</td></tr>
              @endforelse
            </tbody>
          </table>
        </div>
        <h5 class="mb-2">Guru di Lembaga Ini</h5>
        <div class="table-responsive mb-4">
          <table class="table table-sm table-hover align-middle">
            <thead class="table-light">
              <tr><th>No</th><th>Nama</th><th>NUPTK</th><th>Mapel</th><th>Telepon</th></tr>
            </thead>
            <tbody>
              @forelse($institution->teachers as $teacher)
              <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $teacher->nama }}</td>
                <td>{{ $teacher->nuptk ?? '-' }}</td>
                <td>{{ $teacher->mapel ?? '-' }}</td>
                <td>{{ $teacher->telepon }}</td>
              </tr>
              @empty
              <tr><td colspan="5" class="text-center">Tidak ada guru.</td></tr>
              @endforelse
            </tbody>
          </table>
        </div>
        <h5 class="mb-2">Karyawan di Lembaga Ini</h5>
        <div class="table-responsive">
          <table class="table table-sm table-hover align-middle">
            <thead class="table-light">
              <tr><th>No</th><th>Nama</th><th>NIP</th><th>Jabatan</th><th>Telepon</th></tr>
            </thead>
            <tbody>
              @forelse($institution->employees as $employee)
              <tr>
                <td>{{ $loop->iteration }}</td>
                <td>{{ $employee->nama }}</td>
                <td>{{ $employee->nip ?? '-' }}</td>
                <td>{{ $employee->jabatan ?? '-' }}</td>
                <td>{{ $employee->telepon }}</td>
              </tr>
              @empty
              <tr><td colspan="5" class="text-center">Tidak ada karyawan.</td></tr>
              @endforelse
            </tbody>
          </table>
        </div>
      </div>
    </div>
</div>
@endsection 