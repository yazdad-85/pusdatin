@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col">
            <h2 class="mb-2" style="color:#1D4ED8; font-weight:600;">Dashboard EduData Center</h2>
            <p class="text-muted">Selamat datang di pusat data yayasan pendidikan. Kelola data siswa, guru, karyawan, dan arsip digital secara terpusat dan efisien.</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <span class="mr-3" style="font-size:2rem; color:#1D4ED8;">📘</span>
                        <div>
                            <div class="h5 mb-0">Total Siswa</div>
                            <div class="text-muted">{{ $totalStudents ?? '-' }}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <span class="mr-3" style="font-size:2rem; color:#1D4ED8;">👨‍🏫</span>
                        <div>
                            <div class="h5 mb-0">Total Guru</div>
                            <div class="text-muted">{{ $totalTeachers ?? '-' }}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <span class="mr-3" style="font-size:2rem; color:#1D4ED8;">🧑‍💼</span>
                        <div>
                            <div class="h5 mb-0">Total Karyawan</div>
                            <div class="text-muted">{{ $totalEmployees ?? '-' }}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-md-8">
            <div class="card shadow-sm border-0 mb-3">
                <div class="card-header bg-white font-weight-bold">Aktivitas Terbaru</div>
                <div class="card-body">
                    <ul class="list-unstyled mb-0">
                        <li class="text-muted">Belum ada aktivitas terbaru.</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm border-0 mb-3">
                <div class="card-header bg-white font-weight-bold">Aksi Cepat</div>
                <div class="card-body">
                    <a href="#" class="btn btn-primary btn-block mb-2">Tambah Data</a>
                    <a href="#" class="btn btn-warning btn-block mb-2">Upload Arsip</a>
                    <a href="#" class="btn btn-outline-secondary btn-block">Lihat Histori</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
