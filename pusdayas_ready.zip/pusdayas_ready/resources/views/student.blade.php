@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mb-0">Data Siswa</h1>
        <a href="{{ route('student.create') }}" class="btn btn-primary shadow-sm"><i class="fas fa-plus"></i> Tambah Siswa</a>
    </div>
    <div class="card shadow-sm">
        <div class="card-body">
            <form method="GET" class="mb-3 row g-2 align-items-end">
                <div class="col-md-2">
                    <label class="form-label mb-1">Lembaga</label>
                    <select name="institution_id" class="form-control">
                        <option value="">Semua Lembaga</option>
                        @foreach($institutions as $institution)
                            <option value="{{ $institution->id }}" {{ request('institution_id') == $institution->id ? 'selected' : '' }}>{{ $institution->nama_lembaga }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label mb-1">Tahun Akademik</label>
                    <select name="academic_year_id" class="form-control">
                        <option value="">Semua Tahun</option>
                        @foreach($academicYears as $academicYear)
                            <option value="{{ $academicYear->id }}" {{ request('academic_year_id') == $academicYear->id ? 'selected' : '' }}>{{ $academicYear->tahun_akademik }} - {{ $academicYear->semester }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label mb-1">Kelas</label>
                    <select name="kelas" class="form-control">
                        <option value="">Semua Kelas</option>
                        @foreach($kelasList as $kelas)
                            <option value="{{ $kelas }}" {{ request('kelas') == $kelas ? 'selected' : '' }}>{{ $kelas }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label mb-1">Cari</label>
                    <input type="text" name="q" class="form-control" placeholder="Cari nama, NISN, alamat..." value="{{ request('q') }}">
                </div>
                <div class="col-md-2">
                    <button class="btn btn-primary w-100" type="submit"><i class="fas fa-search"></i> Filter</button>
                </div>
                <div class="col-md-1 d-flex align-items-end">
                    <a href="{{ route('student.index') }}" class="btn btn-outline-secondary rounded-circle ms-2" title="Reset Filter" style="width:38px;height:38px;display:flex;align-items:center;justify-content:center;">
                        <i class="fas fa-rotate-left"></i>
                    </a>
                </div>
            </form>
            <div class="table-responsive">
                <form id="bulk-action-form" method="POST" action="{{ route('student.bulkAction') }}">
                    @csrf
                    <div class="mb-2 d-flex gap-2">
                        <button type="submit" name="action" value="naikkan" class="btn btn-success btn-sm" onclick="return confirm('Yakin ingin menaikkan kelas siswa terpilih?')"><i class="fas fa-arrow-up"></i> Naikkan Kelas</button>
                        <button type="submit" name="action" value="luluskan" class="btn btn-primary btn-sm" onclick="return confirm('Yakin ingin meluluskan siswa terpilih?')"><i class="fas fa-graduation-cap"></i> Luluskan</button>
                    </div>
                    <table class="table table-hover table-bordered align-middle">
                        <thead class="thead-dark">
                            <tr>
                                <th><input type="checkbox" id="select-all"></th>
                                <th>No</th>
                                <th>Nama</th>
                                <th>NISN</th>
                                <th>Tahun Masuk</th>
                                <th>Kelas</th>
                                <th>Lembaga</th>
                                <th>Asal Lembaga</th>
                                <th>Alamat</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($students as $student)
                            <tr>
                                <td><input type="checkbox" name="student_ids[]" value="{{ $student->id }}" class="student-checkbox"></td>
                                <td>{{ ($students->currentPage() - 1) * $students->perPage() + $loop->iteration }}</td>
                                <td>{{ $student->nama }}</td>
                                <td>{{ $student->nisn }}</td>
                                <td>{{ $student->tahun_masuk }}</td>
                                <td>{{ $student->kelas }}</td>
                                <td>{{ $student->institution ? $student->institution->nama_lembaga : '-' }}</td>
                                <td>{{ $student->riwayat_pendidikan_sebelumnya ?? '-' }}</td>
                                <td>{{ $student->alamat }}</td>
                                <td>{{ $student->status }}</td>
                                <td>
                                    <a href="{{ route('student.show', $student->id) }}" class="btn btn-sm btn-info" title="Detail"><i class="fas fa-eye" aria-label="Detail" alt="Detail"></i></a>
                                    <a href="{{ route('student.edit', $student->id) }}" class="btn btn-sm btn-warning" title="Edit"><i class="fas fa-pen" aria-label="Edit" alt="Edit"></i></a>
                                    <form action="{{ route('student.destroy', $student->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus siswa ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fas fa-trash" aria-label="Hapus" alt="Hapus"></i></button>
                                    </form>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="11" class="text-center">Belum ada data siswa.</td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </form>
            </div>
            <div class="d-flex justify-content-center mt-3">
                {{ $students->links() }}
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
@endpush

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('select-all').addEventListener('change', function() {
        var checkboxes = document.querySelectorAll('.student-checkbox');
        for (var cb of checkboxes) {
            cb.checked = this.checked;
        }
    });
</script>
@endpush