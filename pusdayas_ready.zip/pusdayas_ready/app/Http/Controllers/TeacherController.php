<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Teacher;
use App\Institution;
use App\AcademicYear;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Excel as ExcelWriter;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\FromArray;
use App\Exports\TeacherTemplateExport;

class TeacherController extends Controller
{
    public function index(Request $request)
    {
        $institutions = Institution::all();
        $query = Teacher::query();
        if ($request->filled('institution_id')) {
            $query->where('institution_id', $request->institution_id);
        }
        if ($request->filled('q')) {
            $q = $request->q;
            $query->where(function($sub) use ($q) {
                $sub->where('nama_lengkap', 'like', "%$q%")
                    ->orWhere('nik', 'like', "%$q%")
                    ->orWhere('nuptk', 'like', "%$q%")
                    ->orWhere('telepon', 'like', "%$q%")
                    ->orWhere('alamat', 'like', "%$q%")
                    ->orWhere('email', 'like', "%$q%")
                ;
            });
        }
        $teachers = $query->with('institution')->orderBy('nama_lengkap')->paginate(10)->appends($request->except('page'));
        return view('teacher', compact('teachers', 'institutions'));
    }

    public function create()
    {
        $institutions = Institution::all();
        $academicYears = AcademicYear::all();
        return view('teacher_create', compact('institutions', 'academicYears'));
    }

    public function store(Request $request)
    {
        $data = $request->except(['_token', '_method', 'foto', 'sk_pengangkatan', 'file_sertifikat', 'file_sk_inpasing', 'file_ijazah', 'file_ktp', 'file_kk', 'file_ijazah_terakhir', 'file_sertifikat_pelatihan', 'file_sk_pengangkatan', 'file_sk_penempatan', 'file_sertifikat_sertifikasi', 'file_berkas_lain']);
        // Encode array fields to JSON
        foreach(['mapel_diampu','mapel_jenjang','mapel_tingkat','mapel_kelas','mapel_jam'] as $arrField) {
            if(isset($data[$arrField])) {
                $data[$arrField] = json_encode($data[$arrField]);
            }
        }
        $guruFolder = 'public/guru/' . ($request->nik ?: $request->nuptk ?: uniqid());
        // Handle file uploads
        foreach ([
            'foto', 'sk_pengangkatan', 'file_sertifikat', 'file_sk_inpasing', 'file_ijazah', 'file_ktp', 'file_kk', 'file_ijazah_terakhir', 'file_sertifikat_pelatihan', 'file_sk_pengangkatan', 'file_sk_penempatan', 'file_sertifikat_sertifikasi', 'file_berkas_lain'
        ] as $field) {
            if ($request->hasFile($field)) {
                $file = $request->file($field);
                $filename = $field . '_' . time() . '.' . $file->getClientOriginalExtension();
                $path = $file->storeAs($guruFolder, $filename);
                $data[$field] = str_replace('public/', '', $path);
            }
        }
        Teacher::create($data);
        return redirect()->route('teacher')->with('success', 'Data guru berhasil ditambahkan.');
    }

    public function show($id)
    {
        $teacher = Teacher::with('institution')->findOrFail($id);
        return view('teacher_show', compact('teacher'));
    }

    public function edit($id)
    {
        $teacher = Teacher::findOrFail($id);
        $institutions = Institution::all();
        $academicYears = AcademicYear::all();
        return view('teacher_edit', compact('teacher', 'institutions', 'academicYears'));
    }

    public function update(Request $request, $id)
    {
        $teacher = Teacher::findOrFail($id);
        $data = $request->except(['_token', '_method', 'foto', 'sk_pengangkatan', 'file_sertifikat', 'file_sk_inpasing', 'file_ijazah', 'file_ktp', 'file_kk', 'file_ijazah_terakhir', 'file_sertifikat_pelatihan', 'file_sk_pengangkatan', 'file_sk_penempatan', 'file_sertifikat_sertifikasi', 'file_berkas_lain']);
        foreach(['mapel_diampu','mapel_jenjang','mapel_tingkat','mapel_kelas','mapel_jam'] as $arrField) {
            if(isset($data[$arrField])) {
                $data[$arrField] = json_encode($data[$arrField]);
            }
        }
        $guruFolder = 'public/guru/' . ($request->nik ?: $request->nuptk ?: $teacher->id);
        foreach ([
            'foto', 'sk_pengangkatan', 'file_sertifikat', 'file_sk_inpasing', 'file_ijazah', 'file_ktp', 'file_kk', 'file_ijazah_terakhir', 'file_sertifikat_pelatihan', 'file_sk_pengangkatan', 'file_sk_penempatan', 'file_sertifikat_sertifikasi', 'file_berkas_lain'
        ] as $field) {
            if ($request->hasFile($field)) {
                $file = $request->file($field);
                $filename = $field . '_' . time() . '.' . $file->getClientOriginalExtension();
                $path = $file->storeAs($guruFolder, $filename);
                $data[$field] = str_replace('public/', '', $path);
            }
        }
        $teacher->update($data);
        return redirect()->route('teacher')->with('success', 'Data guru berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $teacher = Teacher::findOrFail($id);
        $teacher->delete();
        return redirect()->route('teacher')->with('success', 'Data guru berhasil dihapus.');
    }

    // Import & Template Excel (dummy, implementasi detail menyusul)
    public function import(Request $request)
    {
        // Implementasi import Excel
        return back()->with('success', 'Import data guru berhasil (dummy).');
    }
    public function template()
    {
        $user = auth()->user();
        $institutionName = null;
        if ($user && $user->role == 'admin_lembaga' && $user->institution_id) {
            $institution = \App\Institution::find($user->institution_id);
            $institutionName = $institution ? $institution->nama_lembaga : '';
        }
        return \Maatwebsite\Excel\Facades\Excel::download(new TeacherTemplateExport($institutionName), 'template_guru.xlsx');
    }
}
