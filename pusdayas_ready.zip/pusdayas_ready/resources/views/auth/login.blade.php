@extends('layouts.app')

@section('content')
<style>
    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
        overflow-x: hidden;
    }
    .login-landing .container-fluid {
        min-height: 100vh;
        padding: 0;
        margin: 0;
        overflow: hidden;
    }
    .login-landing .row {
        min-height: 100vh;
        margin: 0;
    }
    .login-landing .col-md-6, .login-landing .col-lg-5 {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }
    .login-landing .card {
        width: 100%;
        max-width: 350px;
        margin: 0 auto;
        box-shadow: 0 2px 16px 0 rgba(60,72,100,0.08);
        border-radius: 12px;
    }
    .login-landing .card-header {
        border-radius: 12px 12px 0 0;
    }
    .login-landing .footer {
        width: 100%;
        text-align: center;
        color: #7a869a;
        font-size: 0.95rem;
        margin-top: 2rem;
        margin-bottom: 1rem;
    }
    @media (max-width: 991.98px) {
        .login-landing .col-md-6, .login-landing .col-lg-5 {
            min-height: unset;
            flex: 0 0 100%;
            max-width: 100%;
        }
        .login-landing .mb-4 {
            margin-bottom: 1.5rem!important;
        }
    }
    @media (max-width: 767.98px) {
        .login-landing .container-fluid {
            padding: 0 10px;
        }
        .login-landing .card {
            box-shadow: none;
            max-width: 100%;
        }
        .login-landing .mb-4 {
            margin-bottom: 1rem!important;
        }
        .login-landing .text-center img {
            width: 56px!important;
        }
        .login-landing h2 {
            font-size: 1.2rem!important;
        }
        .login-landing p, .login-landing ul {
            font-size: 0.95rem!important;
        }
        .login-landing .footer {
            margin-top: 1.5rem;
            font-size: 0.9rem;
        }
    }
    @media (max-width: 575.98px) {
        .login-landing .card-body {
            padding: 1rem!important;
        }
        .login-landing .card-header {
            font-size: 1rem!important;
        }
        .login-landing .text-center img {
            width: 44px!important;
        }
        .login-landing .footer {
            margin-top: 1rem;
            margin-bottom: 0.5rem;
        }
    }
</style>
<div class="container-fluid login-landing" style="background: linear-gradient(135deg, #f7fafc 0%, #e3eaf7 100%);">
    <div class="row w-100 justify-content-center align-items-center">
        <div class="col-md-6 col-lg-5 mb-4">
            <div class="w-100">
                <div class="mb-4 text-center">
                    <img src="https://img.icons8.com/fluency/96/000000/school-building.png" alt="Logo Yasmu" style="width:72px;">
                    <h2 class="mt-3 mb-2" style="color:#3b486b; font-weight:700; letter-spacing:1px;">Pusat Data Yayasan Mu'allimin Mu'allimat YASMU</h2>
                    <p class="text-muted" style="font-size:1.1rem;">Sistem terintegrasi untuk pengelolaan data siswa, guru, karyawan, dan arsip digital Yayasan Mu'allimin Mu'allimat YASMU. Aman, mudah, dan efisien untuk kebutuhan administrasi pendidikan modern.</p>
                </div>
                <ul class="list-unstyled mb-4 text-muted" style="font-size:0.98rem;">
                    <li>✔️ Manajemen Data Siswa, Guru, Karyawan</li>
                    <li>✔️ Arsip Digital &amp; Upload Dokumen</li>
                    <li>✔️ Pencarian &amp; Ekspor Data</li>
                    <li>✔️ Hak Akses &amp; Keamanan Data</li>
                </ul>
            </div>
        </div>
        <div class="col-md-6 col-lg-5 mb-4 d-flex flex-column align-items-center justify-content-center">
            <div class="card shadow border-0">
                <div class="card-header bg-white text-center" style="font-weight:600; font-size:1.2rem; color:#3b486b;">Login Admin / Pengguna</div>
                <div class="card-body p-4">
                    <form method="POST" action="{{ route('login') }}">
                        @csrf
                        <div class="form-group mb-3">
                            <label for="email">Alamat Email</label>
                            <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autofocus>
                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="form-group mb-3">
                            <label for="password">Password</label>
                            <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required>
                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="form-group mb-3 form-check">
                            <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                            <label class="form-check-label" for="remember">Ingat Saya</label>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block" style="background:#3b486b; border:none;">Login</button>
                        <div class="mt-3 text-center">
                            @if (Route::has('password.request'))
                                <a class="text-muted" href="{{ route('password.request') }}">Lupa Password?</a>
                            @endif
                        </div>
                    </form>
                </div>
            </div>
            <div class="footer">
                &copy; {{ date('Y') }} Yayasan Mu'allimin Mu'allimat YASMU. All rights reserved.
            </div>
        </div>
    </div>
</div>
@endsection
