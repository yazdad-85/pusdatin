@extends('layouts.app')
@section('content')
<div class="container">
    <h2 class="mb-4">Manajemen Akun & Akses</h2>
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    <div class="mb-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
        <a href="{{ route('user.create') }}" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Akun</a>
    </div>
    <div class="table-responsive">
        <table class="table table-bordered align-middle">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Lembaga</th>
                    <th>Status</th>
                    <th>Foto</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($users as $u)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $u->name }}</td>
                    <td>{{ $u->email }}</td>
                    <td>{{ $u->role }}</td>
                    <td>{{ $u->institution ? $u->institution->nama_lembaga : '-' }}</td>
                    <td>{{ $u->status }}</td>
                    <td>@if($u->foto)<img src="{{ asset('storage/'.$u->foto) }}" alt="foto" style="width:32px;height:32px;border-radius:50%;object-fit:cover;">@else - @endif</td>
                    <td>
                        <a href="{{ route('user.edit', $u->id) }}" class="btn btn-sm btn-warning" title="Edit"><i class="fas fa-pen"></i></a>
                        <form action="{{ route('user.destroy', $u->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin hapus akun?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fas fa-trash"></i></button>
                        </form>
                        <form action="{{ route('user.reset-password', $u->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Reset password ke 123456?')">
                            @csrf
                            <button class="btn btn-sm btn-secondary" type="submit" title="Reset Password"><i class="fas fa-key"></i></button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr><td colspan="8" class="text-center">Belum ada user.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection 