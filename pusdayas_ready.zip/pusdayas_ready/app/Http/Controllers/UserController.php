<?php
namespace App\Http\Controllers;
use App\User;
use App\Institution;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
class UserController extends Controller
{
    public function index() {
        $user = Auth::user();
        if($user->role == 'superadmin') {
            $users = User::with('institution')->orderBy('name')->get();
        } else {
            $users = User::with('institution')->where('institution_id', $user->institution_id)->get();
        }
        return view('user.index', compact('users'));
    }
    public function create() {
        $institutions = Institution::all();
        return view('user.create', compact('institutions'));
    }
    public function store(Request $request) {
        $request->validate([
            'name'=>'required',
            'email'=>'required|email|unique:users,email',
            'role'=>'required',
            'institution_id'=>'required_if:role,admin_lembaga',
        ]);
        $data = $request->only(['name','email','role','institution_id','status']);
        $data['password'] = Hash::make('123456');
        // Upload foto
        if($request->hasFile('foto')) {
            $file = $request->file('foto');
            $filename = 'foto_'.time().'.'.$file->getClientOriginalExtension();
            $path = $file->storeAs('public/user', $filename);
            $data['foto'] = str_replace('public/','',$path);
        }
        User::create($data);
        return redirect()->route('user.index')->with('success','Akun berhasil ditambah. Password default: 123456');
    }
    public function edit($id) {
        $user = Auth::user();
        $target = User::findOrFail($id);
        // Hanya superadmin bisa edit user lain, admin_lembaga hanya bisa edit diri sendiri
        if (auth()->user()->role !== 'superadmin' && auth()->id() != $target->id) {
            abort(403);
        }
        $institutions = Institution::all();
        return view('user.edit', compact('target','institutions'));
    }
    public function update(Request $request, $id) {
        $user = Auth::user();
        $target = User::findOrFail($id);
        // Hanya superadmin bisa update user lain, admin_lembaga hanya bisa update diri sendiri
        if (auth()->user()->role !== 'superadmin' && auth()->id() != $target->id) {
            abort(403);
        }
        $rules = [
            'name' => 'required',
            'email' => 'required|email',
            'status' => 'in:Aktif,Tidak Aktif',
            'foto' => 'nullable|image|max:2048',
        ];
        if ($request->filled('password')) {
            $rules['password'] = 'confirmed|min:6';
        }
        $request->validate($rules);
        $data = $request->only(['name','email','status']);
        if ($request->filled('password')) {
            $data['password'] = Hash::make($request->password);
        }
        if ($request->hasFile('foto')) {
            $file = $request->file('foto');
            $path = $file->store('user_foto','public');
            $data['foto'] = $path;
        }
        // Superadmin bisa update role & institution, admin_lembaga tidak
        if (auth()->user()->role === 'superadmin') {
            $data['role'] = $request->role;
            $data['institution_id'] = $request->institution_id;
        }
        $target->update($data);
        if (auth()->id() == $target->id) {
            return redirect()->route('user.profile')->with('success','Profil berhasil diupdate');
        }
        return redirect()->route('user.index')->with('success','User berhasil diupdate');
    }
    public function profile()
    {
        $user = auth()->user();
        return view('user.profile', compact('user'));
    }
    public function destroy($id) {
        $user = Auth::user();
        $target = User::findOrFail($id);
        // Hanya superadmin bisa hapus user lain, admin_lembaga hanya bisa hapus diri sendiri
        if (auth()->user()->role !== 'superadmin' && auth()->id() != $target->id) {
            abort(403);
        }
        $target->delete();
        return redirect()->route('user.index')->with('success','Akun berhasil dihapus');
    }
    public function resetPassword($id) {
        $user = Auth::user();
        $target = User::findOrFail($id);
        // Hanya superadmin bisa reset password user lain, admin_lembaga hanya bisa reset password diri sendiri
        if (auth()->user()->role !== 'superadmin' && auth()->id() != $target->id) {
            abort(403);
        }
        $target->password = Hash::make('123456');
        $target->save();
        return redirect()->route('user.index')->with('success','Password berhasil direset ke 123456');
    }
} 