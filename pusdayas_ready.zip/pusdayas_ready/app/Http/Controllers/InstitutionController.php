<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Institution;

class InstitutionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = auth()->user();
        
        if ($user->role === 'superadmin') {
            // Superadmin bisa lihat semua lembaga
            $institutions = Institution::all();
        } else {
            // Admin lembaga hanya bisa lihat lembaganya sendiri
            $institutions = Institution::where('id', $user->institution_id)->get();
        }
        
        return view('institutions.index', compact('institutions'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $user = auth()->user();
        
        // Hanya superadmin yang bisa membuat lembaga baru
        if ($user->role !== 'superadmin') {
            abort(403, 'Hanya Superadmin yang dapat membuat lembaga baru.');
        }
        
        return view('institutions.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user = auth()->user();
        
        // Hanya superadmin yang bisa membuat lembaga baru
        if ($user->role !== 'superadmin') {
            abort(403, 'Hanya Superadmin yang dapat membuat lembaga baru.');
        }
        
        $data = $request->except(['_token', '_method']);
        if ($request->hasFile('logo')) {
            $file = $request->file('logo');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('uploads/lembaga'), $filename);
            $data['logo'] = 'uploads/lembaga/' . $filename;
        }
        \App\Institution::create($data);
        return redirect()->route('institutions.index')->with('success', 'Lembaga berhasil ditambahkan.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = auth()->user();
        $institution = \App\Institution::findOrFail($id);
        
        // Admin lembaga hanya bisa lihat lembaganya sendiri
        if ($user->role !== 'superadmin' && $institution->id !== $user->institution_id) {
            abort(403, 'Anda tidak memiliki akses ke lembaga ini.');
        }
        
        return view('institutions.show', compact('institution'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = auth()->user();
        $institution = \App\Institution::findOrFail($id);
        
        // Admin lembaga hanya bisa edit lembaganya sendiri
        if ($user->role !== 'superadmin' && $institution->id !== $user->institution_id) {
            abort(403, 'Anda tidak memiliki akses ke lembaga ini.');
        }
        
        return view('institutions.edit', compact('institution'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $user = auth()->user();
        $institution = \App\Institution::findOrFail($id);
        
        // Admin lembaga hanya bisa update lembaganya sendiri
        if ($user->role !== 'superadmin' && $institution->id !== $user->institution_id) {
            abort(403, 'Anda tidak memiliki akses ke lembaga ini.');
        }
        
        $data = $request->except(['_token', '_method']);
        if ($request->hasFile('logo')) {
            // Hapus logo lama jika ada
            if ($institution->logo && file_exists(public_path($institution->logo))) {
                unlink(public_path($institution->logo));
            }
            $file = $request->file('logo');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('uploads/lembaga'), $filename);
            $data['logo'] = 'uploads/lembaga/' . $filename;
        }
        $institution->update($data);
        return redirect()->route('institutions.index')->with('success', 'Lembaga berhasil diperbarui.');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = auth()->user();
        $institution = \App\Institution::findOrFail($id);
        
        // Admin lembaga hanya bisa hapus lembaganya sendiri
        if ($user->role !== 'superadmin' && $institution->id !== $user->institution_id) {
            abort(403, 'Anda tidak memiliki akses ke lembaga ini.');
        }
        
        if ($institution->logo && file_exists(public_path($institution->logo))) {
            unlink(public_path($institution->logo));
        }
        $institution->delete();
        return redirect()->route('institutions.index')->with('success', 'Lembaga berhasil dihapus.');
    }
}
