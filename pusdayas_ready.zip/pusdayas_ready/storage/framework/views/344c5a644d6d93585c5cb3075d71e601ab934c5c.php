<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Manajemen Akun & Akses</h2>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="mb-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
        <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Tambah Akun</a>
    </div>
    <div class="table-responsive">
        <table class="table table-bordered align-middle">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Lembaga</th>
                    <th>Status</th>
                    <th>Foto</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($u->name); ?></td>
                    <td><?php echo e($u->email); ?></td>
                    <td><?php echo e($u->role); ?></td>
                    <td><?php echo e($u->institution ? $u->institution->nama_lembaga : '-'); ?></td>
                    <td><?php echo e($u->status); ?></td>
                    <td><?php if($u->foto): ?><img src="<?php echo e(asset('storage/'.$u->foto)); ?>" alt="foto" style="width:32px;height:32px;border-radius:50%;object-fit:cover;"><?php else: ?> - <?php endif; ?></td>
                    <td>
                        <a href="<?php echo e(route('user.edit', $u->id)); ?>" class="btn btn-sm btn-warning" title="Edit"><i class="fas fa-pen"></i></a>
                        <form action="<?php echo e(route('user.destroy', $u->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin hapus akun?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fas fa-trash"></i></button>
                        </form>
                        <form action="<?php echo e(route('user.reset-password', $u->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Reset password ke 123456?')">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-sm btn-secondary" type="submit" title="Reset Password"><i class="fas fa-key"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="text-center">Belum ada user.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mbp19/Documents/YAZDAD/APLIKASI PLAN/pusdayas/resources/views/user/index.blade.php ENDPATH**/ ?>