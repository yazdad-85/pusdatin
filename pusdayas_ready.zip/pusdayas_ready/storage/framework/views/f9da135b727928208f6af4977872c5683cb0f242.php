<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap">
        <h2 class="mb-0" style="font-size:1.4rem; font-weight:600;">Tambah Lembaga</h2>
        <a href="<?php echo e(route('institutions.index')); ?>" class="btn btn-secondary btn-sm mt-2 mt-md-0">Kembali</a>
    </div>
    <div class="card shadow-sm">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('institutions.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Nama Lembaga</label>
                        <input type="text" class="form-control" name="nama_lembaga" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">NPSN</label>
                        <input type="text" class="form-control" name="npsn">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Jenis Lembaga</label>
                        <select class="form-control" name="jenis_lembaga" required>
                            <option value="">Pilih Jenjang</option>
                            <option value="MTs">MTs</option>
                            <option value="SMP">SMP</option>
                            <option value="MA">MA</option>
                            <option value="SMA">SMA</option>
                            <option value="SMK">SMK</option>
                            <option value="SD">SD</option>
                            <option value="MI">MI</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Alamat</label>
                        <input type="text" class="form-control" name="alamat">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Telepon</label>
                        <input type="text" class="form-control" name="telepon">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" name="email">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Kepala Lembaga</label>
                        <input type="text" class="form-control" name="kepala_lembaga">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Logo (opsional)</label>
                        <input type="file" class="form-control" name="logo">
                    </div>
                </div>
                <div class="mt-3">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mbp19/Documents/YAZDAD/APLIKASI PLAN/pusdayas/resources/views/institutions/create.blade.php ENDPATH**/ ?>