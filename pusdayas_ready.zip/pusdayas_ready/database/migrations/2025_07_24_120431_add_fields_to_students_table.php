<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldsToStudentsTable extends Migration
{
    public function up()
    {
        Schema::table('students', function (Blueprint $table) {
            $table->string('nis')->nullable();
            $table->string('jenis_kelamin')->nullable();
            $table->string('tempat_lahir')->nullable();
            $table->date('tanggal_lahir')->nullable();
            $table->string('agama')->nullable();
            $table->string('foto')->nullable();
            $table->string('nama_ayah')->nullable();
            $table->string('pekerjaan_ayah')->nullable();
            $table->string('pendidikan_ayah')->nullable();
            $table->string('nama_ibu')->nullable();
            $table->string('pekerjaan_ibu')->nullable();
            $table->string('pendidikan_ibu')->nullable();
            $table->string('nama_wali')->nullable();
            $table->string('pekerjaan_wali')->nullable();
            $table->string('telepon_wali')->nullable();
            $table->string('penghasilan')->nullable();
            $table->string('jenjang')->nullable();
            $table->string('tahun_masuk')->nullable();
            $table->string('status')->nullable();
            $table->string('asal_sekolah')->nullable();
            $table->string('jurusan')->nullable();
            $table->string('riwayat_pendidikan')->nullable();
            $table->string('prestasi')->nullable();
            $table->string('lulus_ke')->nullable();
            $table->string('akta_kelahiran')->nullable();
            $table->string('kartu_keluarga')->nullable();
            $table->string('kartu_kip')->nullable();
            $table->string('ijazah')->nullable();
            $table->string('surat_pindah')->nullable();
            $table->string('beasiswa')->nullable();
            $table->string('jenis_beasiswa')->nullable();
            $table->string('periode_beasiswa')->nullable();
            $table->string('keterangan_beasiswa')->nullable();
        });
    }

    public function down()
    {
        Schema::table('students', function (Blueprint $table) {
            $table->dropColumn([
                'nis', 'jenis_kelamin', 'tempat_lahir', 'tanggal_lahir', 'agama', 'foto',
                'nama_ayah', 'pekerjaan_ayah', 'pendidikan_ayah', 'nama_ibu', 'pekerjaan_ibu', 'pendidikan_ibu',
                'nama_wali', 'pekerjaan_wali', 'telepon_wali', 'penghasilan',
                'jenjang', 'tahun_masuk', 'status', 'asal_sekolah', 'jurusan',
                'riwayat_pendidikan', 'prestasi', 'lulus_ke',
                'akta_kelahiran', 'kartu_keluarga', 'kartu_kip', 'ijazah', 'surat_pindah',
                'beasiswa', 'jenis_beasiswa', 'periode_beasiswa', 'keterangan_beasiswa'
            ]);
        });
    }
}
