@extends('layouts.app')
@section('content')
<div class="container">
    <h2 class="mb-4">Data Karyawan</h2>
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    <div class="mb-3">
        <a href="{{ route('employee.create') }}" class="btn btn-primary shadow-sm"><i class="fas fa-plus"></i> Tambah Karyawan</a>
    </div>
    <div class="card mb-3" style="border-radius:0.5rem;box-shadow:0 1px 4px rgba(44,62,80,0.04);border:1px solid #e3e6f0;">
        <div class="card-body p-3">
            <form method="GET" class="row g-2 align-items-center flex-nowrap flex-wrap">
                <div class="col-auto" style="min-width:160px;">
                    <select name="employee_category_id" class="form-select form-select-sm">
                        <option value="">Semua Kategori</option>
                        @foreach($categories as $cat)
                            <option value="{{ $cat->id }}" {{ request('employee_category_id')==$cat->id?'selected':'' }}>{{ $cat->nama_kategori }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-auto" style="min-width:160px;">
                    <select name="institution_id" class="form-select form-select-sm">
                        <option value="">Semua Lembaga</option>
                        @foreach($institutions as $inst)
                            <option value="{{ $inst->id }}" {{ request('institution_id')==$inst->id?'selected':'' }}>{{ $inst->nama_lembaga }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-auto" style="min-width:180px;">
                    <input type="text" name="q" class="form-control form-control-sm" placeholder="Cari nama, NIK, telepon..." value="{{ request('q') }}">
                </div>
                <div class="col-auto">
                    <button class="btn btn-primary btn-sm" type="submit"><i class="fas fa-search"></i> Filter</button>
                    <a href="{{ route('employee') }}" class="btn btn-outline-secondary btn-sm" title="Reset"><i class="fas fa-rotate-left"></i></a>
                </div>
            </form>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-bordered align-middle">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>NIK</th>
                    <th>Kategori</th>
                    <th>Lembaga</th>
                    <th>Telepon</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($employees as $emp)
                <tr>
                    <td>{{ ($employees->currentPage()-1)*$employees->perPage() + $loop->iteration }}</td>
                    <td>{{ $emp->nama_lengkap }}</td>
                    <td>{{ $emp->nik }}</td>
                    <td>{{ $emp->category ? $emp->category->nama_kategori : '-' }}</td>
                    <td>{{ $emp->institution ? $emp->institution->nama_lembaga : '-' }}</td>
                    <td>{{ $emp->telepon }}</td>
                    <td>{{ $emp->status }}</td>
                    <td>
                        <a href="{{ route('employee.show', $emp->id) }}" class="btn btn-sm btn-info" title="Detail"><i class="fas fa-eye"></i></a>
                        <a href="{{ route('employee.edit', $emp->id) }}" class="btn btn-sm btn-warning" title="Edit"><i class="fas fa-pen"></i></a>
                        <form action="{{ route('employee.destroy', $emp->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin hapus?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr><td colspan="8" class="text-center">Belum ada data karyawan.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="d-flex justify-content-center mt-3">
        {{ $employees->links() }}
    </div>
</div>
@endsection 