@extends('layouts.app')
@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap">
        <h2 class="mb-0" style="font-size:1.4rem; font-weight:600;">Data Lembaga</h2>
        @if(auth()->user()->role === 'superadmin')
        <a href="{{ route('institutions.create') }}" class="btn btn-primary shadow-sm mt-2 mt-md-0">
            <i class="fas fa-plus"></i> Tambah Lembaga
        </a>
        @endif
    </div>
    <div class="card shadow-sm">
        <div class="card-body">
            <form method="GET" class="mb-3">
                <div class="input-group">
                    <input type="text" name="q" class="form-control" placeholder="Cari nama lembaga, NPSN, atau jenis..." value="{{ request('q') }}">
                    <button class="btn btn-outline-secondary" type="submit"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Nama Lembaga</th>
                            <th>NPSN</th>
                            <th>Jenis</th>
                            <th>Kepala</th>
                            <th>Telepon</th>
                            <th>Email</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($institutions as $institution)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $institution->nama_lembaga }}</td>
                            <td>{{ $institution->npsn }}</td>
                            <td>{{ $institution->jenis_lembaga }}</td>
                            <td>{{ $institution->kepala_lembaga }}</td>
                            <td>{{ $institution->telepon }}</td>
                            <td>{{ $institution->email }}</td>
                            <td>
                                <a href="{{ route('institutions.show', $institution->id) }}" class="btn btn-sm btn-info" title="Detail">
                                    <i class="fas fa-eye" aria-label="Detail" alt="Detail"></i>
                                </a>
                                <a href="{{ route('institutions.edit', $institution->id) }}" class="btn btn-sm btn-warning" title="Edit"><i class="fas fa-pen" aria-label="Edit" alt="Edit"></i></a>
                                <form action="{{ route('institutions.destroy', $institution->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus lembaga ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fas fa-trash" aria-label="Hapus" alt="Hapus"></i></button>
                                </form>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="8" class="text-center">Belum ada data lembaga.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection 