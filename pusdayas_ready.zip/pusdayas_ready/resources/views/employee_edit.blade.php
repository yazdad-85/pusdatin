<div class="row mb-2">
  <div class="col-md-6">
    <label class="form-label">Lembaga</label>
    <select class="form-control form-control-xs" name="institution_id" required>
      <option value="">Pilih Lembaga</option>
      @foreach($institutions as $institution)
        <option value="{{ $institution->id }}" {{ $employee->institution_id == $institution->id ? 'selected' : '' }}>{{ $institution->nama_lembaga }}</option>
      @endforeach
    </select>
  </div>
</div> 