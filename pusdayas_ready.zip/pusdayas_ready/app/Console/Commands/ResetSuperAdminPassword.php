<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\User;
use Illuminate\Support\Facades\Hash;

class ResetSuperAdminPassword extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'admin:reset-password {email?} {--password=superadmin123}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Reset password untuk user super admin';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $email = $this->argument('email');
        $newPassword = $this->option('password');
        
        // Jika email tidak diberikan, cari super admin
        if (!$email) {
            $user = User::where('role', 'superadmin')->first();
            if (!$user) {
                $this->error('Tidak ada user super admin ditemukan!');
                return 1;
            }
            $email = $user->email;
        } else {
            $user = User::where('email', $email)->first();
            if (!$user) {
                $this->error('User dengan email ' . $email . ' tidak ditemukan!');
                return 1;
            }
        }
        
        // Reset password
        $user->update([
            'password' => Hash::make($newPassword),
            'status' => 'Aktif',
        ]);
        
        $this->info('Password berhasil direset!');
        $this->info('Email: ' . $email);
        $this->info('Password baru: ' . $newPassword);
        
        return 0;
    }
} 