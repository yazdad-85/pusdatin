@extends('layouts.app')
@section('content')
<div class="container">
    <h2 class="mb-4">Profil Saya</h2>
    <form method="POST" action="{{ route('user.update', $user->id) }}" enctype="multipart/form-data">
        @csrf @method('PUT')
        <div class="row mb-2">
            <div class="col-md-4">
                <label class="form-label">Nama</label>
                <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name', $user->name) }}" required>
                @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-4">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email', $user->email) }}" required>
                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-4">
                <label class="form-label">Status</label>
                <input type="text" class="form-control" value="{{ $user->status }}" readonly>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-md-4">
                <label class="form-label">Lembaga</label>
                <input type="text" class="form-control" value="{{ $user->institution ? $user->institution->nama_lembaga : '-' }}" readonly>
            </div>
            <div class="col-md-4">
                <label class="form-label">Foto Profil (opsional)</label>
                <input type="file" name="foto" class="form-control">
                @if($user->foto)
                <div class="mt-2"><img src="{{ asset('storage/'.$user->foto) }}" alt="foto" style="width:48px;height:48px;border-radius:50%;object-fit:cover;"></div>
                @endif
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-md-4">
                <label class="form-label">Ganti Password (opsional)</label>
                <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" placeholder="Kosongkan jika tidak ingin ganti">
                @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-4">
                <label class="form-label">Konfirmasi Password</label>
                <input type="password" name="password_confirmation" class="form-control" placeholder="Ulangi password baru">
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Update Profil</button>
    </form>
</div>
@endsection 