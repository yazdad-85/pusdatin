<?php
namespace App\Exports;

use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use Maatwebsite\Excel\Concerns\FromArray;

class TeacherTemplateExport implements WithMultipleSheets
{
    protected $institutionName;
    public function __construct($institutionName = null) {
        $this->institutionName = $institutionName;
    }
    public function sheets(): array {
        // Sheet utama
        $headings = [
            'Nama Lengkap', 'NIK', 'NUPTK', 'Tempat Lahir', 'Tanggal Lahir', 'Jenis Kelamin', 'Agama', 'Alamat', 'Status Pernikahan', 'Telepon', 'Status', 'Email', 'Lembaga'
        ];
        $data = [
            [
                '', '', '', '', '', '', '', '', '', '', 'Aktif', '', $this->institutionName
            ]
        ];
        $mainSheet = new class($data, $headings) implements FromArray, WithHeadings {
            private $data, $headings;
            public function __construct($data, $headings) { $this->data = $data; $this->headings = $headings; }
            public function array(): array { return $this->data; }
            public function headings(): array { return $this->headings; }
        };
        // Sheet petunjuk
        $petunjuk = [
            ['PETUNJUK PENGISIAN'],
            ['- Isi data sesuai kolom yang tersedia.'],
            ['- Kolom "Lembaga" sudah otomatis terisi, tidak perlu diubah.'],
            ['- Kolom "Status" diisi "Aktif" atau "Non Aktif".'],
            ['- Tanggal lahir format YYYY-MM-DD (misal: 1980-01-31).'],
            ['- Data rangkap (mapel, kelas, tingkat, jam) diisi manual setelah import melalui menu edit.'],
            ['- Simpan file dalam format Excel (xlsx) sebelum diupload.'],
            ['- Jika ada pertanyaan, hubungi superadmin.'],
        ];
        $petunjukSheet = new class($petunjuk) implements FromArray, WithHeadings {
            private $data;
            public function __construct($data) { $this->data = $data; }
            public function array(): array { return $this->data; }
            public function headings(): array { return []; }
        };
        return [
            'Data Guru' => $mainSheet,
            'Petunjuk' => $petunjukSheet
        ];
    }
} 