<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use App\Student;
use App\AcademicYear;
use App\Exports\StudentTemplateExport;

class StudentController extends Controller
{
    public function index(Request $request)
    {
        $query = \App\Student::query();
        $institutions = \App\Institution::all();
        $academicYears = \App\AcademicYear::all();
        $kelasList = \App\Student::select('kelas')->distinct()->pluck('kelas');

        if ($request->filled('institution_id')) {
            $query->where('institution_id', $request->institution_id);
        }
        if ($request->filled('academic_year_id')) {
            $query->where('academic_year_id', $request->academic_year_id);
        }
        if ($request->filled('kelas')) {
            $query->where('kelas', $request->kelas);
        }
        if ($request->filled('q')) {
            $q = $request->q;
            $query->where(function($sub) use ($q) {
                $sub->where('nama', 'like', "%$q%")
                    ->orWhere('nisn', 'like', "%$q%")
                    ->orWhere('telepon', 'like', "%$q%")
                    ->orWhere('alamat', 'like', "%$q%")
                    ->orWhere('kelas', 'like', "%$q%")
                    ->orWhere('nis', 'like', "%$q%")
                ;
            });
        }
        $students = $query->with(['institution', 'academicYear'])->orderBy('nama')->paginate(10)->appends($request->except('page'));
        return view('student', compact('students', 'institutions', 'academicYears', 'kelasList'));
    }

    public function create()
    {
        $institutions = \App\Institution::all();
        $academicYears = \App\AcademicYear::all();
        return view('student_create', compact('institutions', 'academicYears'));
    }

    public function store(Request $request)
    {
        Student::create($request->all());
        return redirect()->route('student.index')->with('success', 'Data siswa berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $student = \App\Student::findOrFail($id);
        $institutions = \App\Institution::all();
        $academicYears = \App\AcademicYear::all();
        return view('student_edit', compact('student', 'institutions', 'academicYears'));
    }

    public function update(Request $request, $id)
    {
        $student = Student::findOrFail($id);
        $student->update($request->all());
        return redirect()->route('student.index')->with('success', 'Data siswa berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $student = Student::findOrFail($id);
        $student->delete();
        return redirect()->route('student.index')->with('success', 'Data siswa berhasil dihapus.');
    }

    public function import(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xlsx,xls'
        ]);
        $file = $request->file('file');
        $data = \PhpOffice\PhpSpreadsheet\IOFactory::load($file->getRealPath())->getActiveSheet()->toArray();
        unset($data[0]); // Hilangkan baris header
        foreach ($data as $row) {
            Student::create([
                'nama' => $row[0],
                'nisn' => $row[1],
                'email' => $row[2],
                'kelas' => $row[3],
                'telepon' => $row[4],
                'alamat' => $row[5],
            ]);
        }
        return redirect()->route('student.index')->with('success', 'Import data siswa berhasil.');
    }

    public function template()
    {
        return Excel::download(new StudentTemplateExport, 'template_siswa.xlsx');
    }

    public function show($id)
    {
        $student = Student::findOrFail($id);
        return view('student_show', compact('student'));
    }

    public function bulkAction(Request $request)
    {
        \Log::info('BulkAction called', [
            'method' => $request->method(),
            'student_ids' => $request->input('student_ids'),
            'action' => $request->input('action'),
            'all' => $request->all(),
        ]);
        $ids = $request->input('student_ids', []);
        $action = $request->input('action');
        if (empty($ids) || !in_array($action, ['naikkan', 'luluskan'])) {
            return redirect()->route('student.index')->with('error', 'Tidak ada siswa yang dipilih atau aksi tidak valid.');
        }
        $students = Student::whereIn('id', $ids)->get();
        $updated = 0;
        if ($action === 'naikkan') {
            foreach ($students as $student) {
                // Kenaikan tingkat otomatis
                $tingkat = (int) $student->tingkat;
                if ($tingkat >= 1 && $tingkat < 12) {
                    $student->tingkat = $tingkat + 1;
                }
                // Kenaikan kelas (misal: 7A -> 8A, 8A -> 9A, dst, jika format kelas angka)
                if (preg_match('/^(\d+)(.*)$/', $student->kelas, $matches)) {
                    $kelasBaru = ((int)$matches[1] + 1) . $matches[2];
                    $student->kelas = $kelasBaru;
                }
                $student->save();
                $updated++;
            }
            return redirect()->route('student.index')->with('success', "$updated siswa berhasil dinaikkan kelas.");
        } elseif ($action === 'luluskan') {
            foreach ($students as $student) {
                $student->status = 'Lulus';
                $student->save();
                $updated++;
            }
            return redirect()->route('student.index')->with('success', "$updated siswa berhasil diluluskan.");
        }
        return redirect()->route('student.index')->with('error', 'Aksi tidak dikenali.');
    }
}
