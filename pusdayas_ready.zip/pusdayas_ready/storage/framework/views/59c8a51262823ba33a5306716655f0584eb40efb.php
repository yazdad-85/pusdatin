<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap">
        <h2 class="mb-0" style="font-size:1.4rem; font-weight:600;">Data Lembaga</h2>
        <?php if(auth()->user()->role === 'superadmin'): ?>
        <a href="<?php echo e(route('institutions.create')); ?>" class="btn btn-primary shadow-sm mt-2 mt-md-0">
            <i class="fas fa-plus"></i> Tambah Lembaga
        </a>
        <?php endif; ?>
    </div>
    <div class="card shadow-sm">
        <div class="card-body">
            <form method="GET" class="mb-3">
                <div class="input-group">
                    <input type="text" name="q" class="form-control" placeholder="Cari nama lembaga, NPSN, atau jenis..." value="<?php echo e(request('q')); ?>">
                    <button class="btn btn-outline-secondary" type="submit"><i class="fas fa-search"></i></button>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Nama Lembaga</th>
                            <th>NPSN</th>
                            <th>Jenis</th>
                            <th>Kepala</th>
                            <th>Telepon</th>
                            <th>Email</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($institution->nama_lembaga); ?></td>
                            <td><?php echo e($institution->npsn); ?></td>
                            <td><?php echo e($institution->jenis_lembaga); ?></td>
                            <td><?php echo e($institution->kepala_lembaga); ?></td>
                            <td><?php echo e($institution->telepon); ?></td>
                            <td><?php echo e($institution->email); ?></td>
                            <td>
                                <a href="<?php echo e(route('institutions.show', $institution->id)); ?>" class="btn btn-sm btn-info" title="Detail">
                                    <i class="fas fa-eye" aria-label="Detail" alt="Detail"></i>
                                </a>
                                <a href="<?php echo e(route('institutions.edit', $institution->id)); ?>" class="btn btn-sm btn-warning" title="Edit"><i class="fas fa-pen" aria-label="Edit" alt="Edit"></i></a>
                                <form action="<?php echo e(route('institutions.destroy', $institution->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus lembaga ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fas fa-trash" aria-label="Hapus" alt="Hapus"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center">Belum ada data lembaga.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mbp19/Documents/YAZDAD/APLIKASI PLAN/pusdayas/resources/views/institutions/index.blade.php ENDPATH**/ ?>