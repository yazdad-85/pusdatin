<?php
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect()->route('dashboard');
});

Route::get('/dashboard', 'HomeController@index')->name('dashboard');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('student/template', 'StudentController@template')->name('student.template');
Route::post('student/import', 'StudentController@import')->name('student.import');
Route::post('students-bulk-action', 'StudentController@bulkAction')->name('student.bulkAction');
Route::resource('student', 'StudentController');
Route::get('/teacher', 'TeacherController@index')->name('teacher');
Route::group(['middleware' => ['auth']], function() {
    Route::get('teacher/template', 'TeacherController@template')->name('teacher.template');
    Route::post('teacher/import', 'TeacherController@import')->name('teacher.import');
    Route::resource('teacher', 'TeacherController');
    Route::resource('employee', 'EmployeeController');
    Route::resource('employee-categories', 'EmployeeCategoryController');
    Route::resource('user', 'UserController');
    Route::post('user/{id}/reset-password', 'UserController@resetPassword')->name('user.reset-password');
    Route::resource('academic-year', 'AcademicYearController');
});
Route::get('/employee', 'EmployeeController@index')->name('employee');
Route::get('/archives/students', 'ArchiveStudentController@index')->name('archives.students');
Route::get('/archives/teachers', 'ArchiveTeacherController@index')->name('archives.teachers');
Route::get('/archives/employees', 'ArchiveEmployeeController@index')->name('archives.employees');
Route::get('/archives/upload', 'ArchiveUploadController@index')->name('archives.upload');
Route::get('/search', 'SearchController@index')->name('search');
Route::get('/export/pdf', 'ExportPdfController@index')->name('export.pdf');
Route::get('/export/excel', 'ExportExcelController@index')->name('export.excel');
Route::resource('institutions', 'InstitutionController');
Route::post('/test-bulk', function() { return 'OK'; });
Route::get('/profile', 'UserController@profile')->name('user.profile');
Route::get('/accounts', 'UserController@index')->name('accounts.index');
