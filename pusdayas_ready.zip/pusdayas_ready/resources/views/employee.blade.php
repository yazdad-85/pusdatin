@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Data Karyawan</h1>
    <p>Halaman ini akan menampilkan data karyawan.</p>
</div>
@endsection