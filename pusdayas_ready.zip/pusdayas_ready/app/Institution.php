<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Institution extends Model
{
    protected $fillable = [
        'nama_lembaga', 'npsn', 'jenis_lembaga', 'alamat', 'telepon', 'email', 'kepala_lembaga', 'logo'
    ];

    public function students()
    {
        return $this->hasMany(\App\Student::class);
    }
    public function teachers()
    {
        return $this->hasMany(\App\Teacher::class);
    }
    public function employees()
    {
        return $this->hasMany(\App\Employee::class);
    }
}
