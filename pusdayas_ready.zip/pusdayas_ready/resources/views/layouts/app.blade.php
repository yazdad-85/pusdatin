@php $isGuest = Auth::guest(); @endphp
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'EduData Center') }}</title>
    <link href="https://fonts.googleapis.com/css?family=Inter:400,600&display=swap" rel="stylesheet">
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: #f7fafc; }
        .sidebar {
            width: 220px;
            background: #232946;
            color: #fff;
            min-height: 100vh;
            position: fixed;
            box-shadow: 2px 0 8px rgba(44,62,80,0.04);
            transition: transform 0.3s ease;
            z-index: 1050;
            left: 0;
            top: 0;
            display: flex;
            flex-direction: column;
        }
        .sidebar .logo {
            font-size: 1.3rem;
            font-weight: bold;
            padding: 1.2rem 1.2rem 0.7rem 1.2rem;
            color: #eebbc3;
            letter-spacing: 1px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin: 0.08rem 0;
        }
        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.45rem 1.1rem;
            border-radius: 0.375rem;
            transition: background 0.18s, color 0.18s;
            font-size: 0.97rem;
            min-height: 36px;
        }
        .sidebar ul li a.active, .sidebar ul li a:hover {
            background: #eebbc3;
            color: #232946;
        }
        .sidebar .menu-section {
            margin-top: 0.7rem;
        }
        .sidebar .menu-title {
            font-size: 0.89rem;
            color: #b8c1ec;
            margin: 0.7rem 1.1rem 0.3rem 1.1rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: space-between;
            user-select: none;
        }
        .sidebar .menu-title span {
            font-size: 1em;
            transition: transform 0.2s;
        }
        .sidebar ul.collapse-menu {
            padding-left: 0.1rem;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s cubic-bezier(.4,0,.2,1);
        }
        .sidebar ul.collapse-menu.open {
            max-height: 400px;
            transition: max-height 0.5s cubic-bezier(.4,0,.2,1);
        }
        .main-content { margin-left: 220px; padding: 1.5rem 1.5rem 1.5rem 2rem; transition: margin-left 0.3s ease; }
        .sidebar-toggle { display: none; position: fixed; top: 1rem; left: 1rem; z-index: 1100; background: #232946; color: #fff; border: none; border-radius: 50%; width: 40px; height: 40px; align-items: center; justify-content: center; font-size: 1.3rem; box-shadow: 0 2px 8px rgba(44,62,80,0.08); }
        .sidebar-close { display: none; position: absolute; top: 1rem; right: 1rem; background: #fff; color: #232946; border: none; border-radius: 50%; width: 32px; height: 32px; align-items: center; justify-content: center; font-size: 1.1rem; box-shadow: 0 2px 8px rgba(44,62,80,0.08); z-index: 1200; }
        .sidebar-overlay { display: none; position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(44,62,80,0.18); z-index: 1049; transition: opacity 0.3s; }
        @media (max-width: 991.98px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .main-content { margin-left: 0; padding: 1rem; }
            .sidebar-toggle { display: flex; }
            .sidebar-close { display: flex; }
            .sidebar-overlay { display: block; opacity: 0; pointer-events: none; }
            .sidebar.active ~ .sidebar-overlay { opacity: 1; pointer-events: auto; }
            body.sidebar-open { overflow: hidden; }
        }
        @media (min-width: 992px) {
            .sidebar { transform: translateX(0); }
            .sidebar-toggle { display: none; }
            .sidebar-close { display: none; }
            .sidebar-overlay { display: none; }
        }
        
        /* Fix dropdown positioning */
        .dropdown-menu {
            z-index: 9999 !important;
            position: absolute !important;
            display: none !important;
        }
        
        .dropdown-menu.show {
            display: block !important;
        }
        
        .navbar-nav .dropdown-menu {
            position: absolute !important;
            top: 100% !important;
            right: 0 !important;
            left: auto !important;
        }
        
        /* Ensure dropdown is above everything */
        .navbar-nav .nav-item.dropdown {
            position: relative !important;
        }
        
        /* Make sure dropdown toggle is clickable */
        .dropdown-toggle {
            cursor: pointer !important;
            user-select: none !important;
        }
        
        /* Force dropdown to be visible when shown */
        .dropdown-menu.show {
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
            transform: none !important;
            pointer-events: auto !important;
        }
        
        /* Ensure dropdown is always on top */
        .navbar-nav .nav-item.dropdown {
            position: relative !important;
        }
        
        .navbar-nav .dropdown-menu {
            position: absolute !important;
            top: 100% !important;
            right: 0 !important;
            left: auto !important;
            z-index: 99999 !important;
            min-width: 200px !important;
            background-color: white !important;
            border: 1px solid rgba(0,0,0,.15) !important;
            border-radius: 0.375rem !important;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,.175) !important;
            margin-top: 0 !important;
            padding: 0.5rem 0 !important;
        }
        
        /* Force dropdown to be visible on all pages */
        .navbar-nav .nav-item.dropdown .dropdown-menu.show {
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
            transform: none !important;
            pointer-events: auto !important;
            position: absolute !important;
            top: 100% !important;
            right: 0 !important;
            left: auto !important;
            z-index: 999999 !important;
            background-color: white !important;
            border: 1px solid rgba(0,0,0,.15) !important;
            border-radius: 0.375rem !important;
            box-shadow: 0 0.5rem 1rem rgba(0,0,0,.175) !important;
            min-width: 200px !important;
            margin-top: 0 !important;
            padding: 0.5rem 0 !important;
        }
        
        /* Additional backup rules */
        .dropdown-menu.show {
            display: block !important;
            visibility: visible !important;
            opacity: 1 !important;
            transform: none !important;
            pointer-events: auto !important;
        }
        
        /* Ensure dropdown items are clickable */
        .dropdown-item {
            cursor: pointer !important;
            display: block !important;
            width: 100% !important;
            padding: 0.25rem 1rem !important;
            clear: both !important;
            font-weight: 400 !important;
            color: #212529 !important;
            text-align: inherit !important;
            text-decoration: none !important;
            white-space: nowrap !important;
            background-color: transparent !important;
            border: 0 !important;
        }
        
        .dropdown-item:hover {
            color: #1e2125 !important;
            background-color: #e9ecef !important;
        }
    </style>
</head>
<body>
@if($isGuest)
    <div class="container py-5">
        <main>
            @yield('content')
        </main>
    </div>
@else
    <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle Sidebar">☰</button>
    <div class="sidebar" id="sidebar">
        <button class="sidebar-close" id="sidebarClose" aria-label="Tutup Sidebar">&times;</button>
        <div class="logo">EduData Center</div>
        <ul>
            <li><a href="{{ url('/dashboard') }}" class="{{ request()->is('dashboard') ? 'active' : '' }}"><i class="fas fa-home"></i> Dashboard</a></li>
        </ul>
        <div class="menu-section">
            <div class="menu-title" onclick="toggleMenu('dataMasterMenu')">Data Master <span id="icon-dataMasterMenu">▼</span></div>
            <ul id="dataMasterMenu" class="collapse-menu">
                <li><a href="{{ url('/student') }}"><i class="fas fa-user-graduate"></i> Siswa</a></li>
                <li><a href="{{ url('/teacher') }}"><i class="fas fa-chalkboard-teacher"></i> Guru</a></li>
                <li><a href="{{ url('/employee') }}"><i class="fas fa-user-tie"></i> Karyawan</a></li>
                <li><a href="{{ url('/institutions') }}"><i class="fas fa-building"></i> Data Lembaga</a></li>
                <li><a href="{{ route('academic-year.index') }}"><i class="fas fa-calendar-alt"></i> Tahun Akademik</a></li>
            </ul>
        </div>
        <div class="menu-section">
            <div class="menu-title" onclick="toggleMenu('arsipMenu')">Arsip Digital <span id="icon-arsipMenu">▼</span></div>
            <ul id="arsipMenu" class="collapse-menu">
                <li><a href="{{ url('/archives/students') }}"><i class="fas fa-folder-open"></i> File Dokumen Siswa</a></li>
                <li><a href="{{ url('/archives/teachers') }}"><i class="fas fa-folder-open"></i> File Dokumen Guru</a></li>
                <li><a href="{{ url('/archives/employees') }}"><i class="fas fa-folder-open"></i> File Karyawan</a></li>
                <li><a href="{{ url('/archives/upload') }}"><i class="fas fa-upload"></i> Upload Baru</a></li>
            </ul>
        </div>
        {{-- Hapus section PENCARIAN & EKSPOR --}}
        <div class="menu-section">
            <div class="menu-title" onclick="toggleMenu('manajemenMenu')">Manajemen <span id="icon-manajemenMenu">▼</span></div>
            <ul id="manajemenMenu" class="collapse-menu">
                <li><a href="{{ route('employee-categories.index') }}"><i class="fas fa-list"></i> Kategori Karyawan</a></li>
                <li><a href="{{ route('user.index') }}"><i class="fas fa-user-shield"></i> Akun & Akses</a></li>
            </ul>
        </div>
    </div>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    <div class="main-content" id="mainContent">
        <nav class="navbar navbar-light bg-white shadow-sm mb-4 rounded" style="margin-left: -2rem; margin-right: -2rem;">
            <div class="container-fluid d-flex justify-content-end">
                <ul class="navbar-nav flex-row">
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            {{ Auth::user()->name }} <span class="caret"></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="{{ route('user.profile') }}">
                                <i class="fas fa-user me-2"></i> Profil Saya
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-danger" href="{{ route('logout') }}"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <i class="fas fa-sign-out-alt me-2"></i> {{ __('Logout') }}
                            </a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                @csrf
                            </form>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
        <main>
            @yield('content')
        </main>
        <footer style="margin-top:2rem;text-align:center;color:#7b8794;font-size:0.95rem;">
            &copy; {{ date('Y') }} EduData Center
        </footer>
    </div>
@endif
<script>
    function toggleMenu(menuId) {
        var menu = document.getElementById(menuId);
        var icon = document.getElementById('icon-' + menuId);
        if (!menu || !icon) return;
        var isOpen = menu.classList.contains('open');
        if (!isOpen) {
            menu.classList.add('open');
            icon.innerText = '▲';
        } else {
            menu.classList.remove('open');
            icon.innerText = '▼';
        }
    }
    document.addEventListener('DOMContentLoaded', function() {
        var sidebar = document.getElementById('sidebar');
        var sidebarToggle = document.getElementById('sidebarToggle');
        var sidebarClose = document.getElementById('sidebarClose');
        var sidebarOverlay = document.getElementById('sidebarOverlay');
        var mainContent = document.getElementById('mainContent');
        if (sidebarToggle && sidebar) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('active');
                document.body.classList.toggle('sidebar-open');
            });
        }
        if (sidebarClose && sidebar) {
            sidebarClose.addEventListener('click', function() {
                sidebar.classList.remove('active');
                document.body.classList.remove('sidebar-open');
            });
        }
        if (sidebarOverlay && sidebar) {
            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.remove('active');
                document.body.classList.remove('sidebar-open');
            });
        }
        // Swipe gesture to close sidebar on mobile
        var startX = null;
        if (sidebar) {
            sidebar.addEventListener('touchstart', function(e) {
                if (window.innerWidth < 992) {
                    startX = e.touches[0].clientX;
                }
            });
            sidebar.addEventListener('touchmove', function(e) {
                if (window.innerWidth < 992 && startX !== null) {
                    var diffX = e.touches[0].clientX - startX;
                    if (diffX < -60) { // swipe left
                        sidebar.classList.remove('active');
                        document.body.classList.remove('sidebar-open');
                        startX = null;
                    }
                }
            });
        }
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(e) {
            if(window.innerWidth < 992 && sidebar && sidebar.classList.contains('active')) {
                // Don't close sidebar if clicking on dropdown elements
                if (e.target.closest('.dropdown-menu') || e.target.closest('.dropdown-toggle')) {
                    return;
                }
                if (!sidebar.contains(e.target) && (!sidebarToggle || !sidebarToggle.contains(e.target))) {
                    sidebar.classList.remove('active');
                    document.body.classList.remove('sidebar-open');
                }
            }
        });
        // Buka menu Data Master secara default
        if (typeof toggleMenu === 'function') {
            toggleMenu('dataMasterMenu');
        }
        
        // Simple dropdown toggle for navbar - more robust version
        function initDropdown() {
            var navbarDropdown = document.getElementById('navbarDropdown');
            var dropdownMenu = navbarDropdown ? navbarDropdown.nextElementSibling : null;
            
            if (navbarDropdown && dropdownMenu) {
                // Remove existing listeners to prevent duplicates
                navbarDropdown.removeEventListener('click', dropdownClickHandler);
                document.removeEventListener('click', documentClickHandler);
                
                // Remove Bootstrap data attributes to prevent conflicts
                navbarDropdown.removeAttribute('data-bs-toggle');
                navbarDropdown.removeAttribute('aria-expanded');
                
                // Add new listeners
                navbarDropdown.addEventListener('click', dropdownClickHandler);
                document.addEventListener('click', documentClickHandler);
            }
        }
        
        function dropdownClickHandler(e) {
            e.preventDefault();
            e.stopPropagation();
            var dropdownMenu = this.nextElementSibling;
            if (dropdownMenu) {
                // Force remove any Bootstrap classes first
                dropdownMenu.classList.remove('show');
                dropdownMenu.classList.remove('dropdown-menu');
                dropdownMenu.classList.add('dropdown-menu');
                dropdownMenu.classList.add('show');
                
                // Force inline styles
                dropdownMenu.style.display = 'block';
                dropdownMenu.style.visibility = 'visible';
                dropdownMenu.style.opacity = '1';
                dropdownMenu.style.zIndex = '999999';
                dropdownMenu.style.position = 'absolute';
                dropdownMenu.style.top = '100%';
                dropdownMenu.style.right = '0';
                dropdownMenu.style.left = 'auto';
                dropdownMenu.style.backgroundColor = 'white';
                dropdownMenu.style.border = '1px solid rgba(0,0,0,.15)';
                dropdownMenu.style.borderRadius = '0.375rem';
                dropdownMenu.style.boxShadow = '0 0.5rem 1rem rgba(0,0,0,.175)';
                dropdownMenu.style.minWidth = '200px';
                dropdownMenu.style.marginTop = '0';
                dropdownMenu.style.padding = '0.5rem 0';
            }
        }
        
        function documentClickHandler(e) {
            var navbarDropdown = document.getElementById('navbarDropdown');
            var dropdownMenu = navbarDropdown ? navbarDropdown.nextElementSibling : null;
            
            if (navbarDropdown && dropdownMenu && !navbarDropdown.contains(e.target) && !dropdownMenu.contains(e.target)) {
                dropdownMenu.classList.remove('show');
            }
        }
        
        // Initialize dropdown
        initDropdown();
        
        // Re-initialize after a short delay to ensure DOM is ready
        setTimeout(initDropdown, 100);
        
        // Additional initialization attempts
        setTimeout(initDropdown, 500);
        setTimeout(initDropdown, 1000);
        
        // Also try to initialize on window load
        window.addEventListener('load', function() {
            setTimeout(initDropdown, 100);
        });
        

    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

@stack('scripts')
</body>
</html>
