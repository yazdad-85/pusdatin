@extends('layouts.app')
@section('content')
<div class="container">
    <h2 class="mb-4" style="font-size:1.3rem;">Edit Guru</h2>
    <form method="POST" action="{{ route('teacher.update', $teacher->id) }}" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <ul class="nav nav-tabs mb-3 flex-nowrap overflow-auto" id="teacherTab" role="tablist" style="white-space:nowrap; gap:0.5rem; font-size:0.95rem;">
            <li class="nav-item" role="presentation"><button class="nav-link active" id="pribadi-tab" data-bs-toggle="tab" data-bs-target="#pribadi" type="button" role="tab">A. Data Pribadi</button></li>
            <li class="nav-item" role="presentation"><button class="nav-link" id="kepegawaian-tab" data-bs-toggle="tab" data-bs-target="#kepegawaian" type="button" role="tab">B. Data Kepegawaian</button></li>
            <li class="nav-item" role="presentation"><button class="nav-link" id="khusus-tab" data-bs-toggle="tab" data-bs-target="#khusus" type="button" role="tab">C. Status Khusus</button></li>
            <li class="nav-item" role="presentation"><button class="nav-link" id="akademik-tab" data-bs-toggle="tab" data-bs-target="#akademik" type="button" role="tab">D. Data Akademik</button></li>
            <li class="nav-item" role="presentation"><button class="nav-link" id="arsip-tab" data-bs-toggle="tab" data-bs-target="#arsip" type="button" role="tab">E. Berkas & Arsip</button></li>
        </ul>
        <div class="tab-content" id="teacherTabContent">
            <!-- Data Pribadi -->
            <div class="tab-pane fade show active" id="pribadi" role="tabpanel">
                <div class="row mb-2">
                    <div class="col-md-6"><label class="form-label">Nama Lengkap</label><input type="text" class="form-control" name="nama_lengkap" value="{{ $teacher->nama_lengkap }}" required></div>
                    <div class="col-md-3"><label class="form-label">NIK</label><input type="text" class="form-control" name="nik" value="{{ $teacher->nik }}"></div>
                    <div class="col-md-3"><label class="form-label">NUPTK</label><input type="text" class="form-control" name="nuptk" value="{{ $teacher->nuptk }}"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Tempat Lahir</label><input type="text" class="form-control" name="tempat_lahir" value="{{ $teacher->tempat_lahir }}"></div>
                    <div class="col-md-4"><label class="form-label">Tanggal Lahir</label><input type="date" class="form-control" name="tanggal_lahir" value="{{ $teacher->tanggal_lahir }}"></div>
                    <div class="col-md-4"><label class="form-label">Jenis Kelamin</label><select class="form-control" name="jenis_kelamin"><option value="">Pilih</option><option value="Laki-laki" {{ $teacher->jenis_kelamin=='Laki-laki'?'selected':'' }}>Laki-laki</option><option value="Perempuan" {{ $teacher->jenis_kelamin=='Perempuan'?'selected':'' }}>Perempuan</option></select></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Agama</label><input type="text" class="form-control" name="agama" value="{{ $teacher->agama }}"></div>
                    <div class="col-md-8"><label class="form-label">Alamat Lengkap</label><input type="text" class="form-control" name="alamat" value="{{ $teacher->alamat }}"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Status Pernikahan</label><input type="text" class="form-control" name="status_pernikahan" value="{{ $teacher->status_pernikahan }}"></div>
                    <div class="col-md-4"><label class="form-label">Nomor HP/Kontak</label><input type="text" class="form-control" name="telepon" value="{{ $teacher->telepon }}"></div>
                    <div class="col-md-4"><label class="form-label">Status</label><select class="form-control" name="status"><option value="Aktif" {{ $teacher->status=='Aktif'?'selected':'' }}>Aktif</option><option value="Non Aktif" {{ $teacher->status=='Non Aktif'?'selected':'' }}>Non Aktif</option></select></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-6"><label class="form-label">Email (opsional)</label><input type="email" class="form-control" name="email" value="{{ $teacher->email }}"></div>
                    <div class="col-md-6"><label class="form-label">Foto (upload)</label><input type="file" class="form-control" name="foto"></div>
                </div>
                <!-- Hapus field Lembaga di sini -->
            </div>
            <!-- Data Kepegawaian -->
            <div class="tab-pane fade" id="kepegawaian" role="tabpanel">
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Status Kepegawaian</label><select class="form-control" name="status_kepegawaian"><option value="">Pilih</option><option value="PNS" {{ $teacher->status_kepegawaian=='PNS'?'selected':'' }}>PNS</option><option value="Non-PNS" {{ $teacher->status_kepegawaian=='Non-PNS'?'selected':'' }}>Non-PNS</option><option value="Honorer" {{ $teacher->status_kepegawaian=='Honorer'?'selected':'' }}>Honorer</option></select></div>
                    <div class="col-md-4"><label class="form-label">TMT (Tanggal Mulai Tugas)</label><input type="date" class="form-control" name="tmt" value="{{ $teacher->tmt }}"></div>
                    <div class="col-md-4"><label class="form-label">SK Pengangkatan (upload)</label><input type="file" class="form-control" name="sk_pengangkatan"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Nomor SK</label><input type="text" class="form-control" name="nomor_sk" value="{{ $teacher->nomor_sk }}"></div>
                    <div class="col-md-4"><label class="form-label">Instansi Pengangkat</label><input type="text" class="form-control" name="instansi_pengangkat" value="{{ $teacher->instansi_pengangkat }}"></div>
                    <div class="col-md-4"><label class="form-label">Pangkat/Golongan</label><input type="text" class="form-control" name="pangkat_golongan" value="{{ $teacher->pangkat_golongan }}"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Gaji Pokok (opsional)</label><input type="number" class="form-control" name="gaji_pokok" value="{{ $teacher->gaji_pokok }}"></div>
                </div>
            </div>
            <!-- Status Khusus -->
            <div class="tab-pane fade" id="khusus" role="tabpanel">
                <div class="row mb-2">
                    <div class="col-md-3"><label class="form-label">Sertifikasi Guru</label><select class="form-control" name="sertifikasi_guru"><option value="">Pilih</option><option value="Sudah" {{ $teacher->sertifikasi_guru=='Sudah'?'selected':'' }}>Sudah</option><option value="Belum" {{ $teacher->sertifikasi_guru=='Belum'?'selected':'' }}>Belum</option></select></div>
                    <div class="col-md-3"><label class="form-label">Nomor Sertifikat</label><input type="text" class="form-control" name="nomor_sertifikat" value="{{ $teacher->nomor_sertifikat }}"></div>
                    <div class="col-md-3"><label class="form-label">Mata Pelajaran Sertifikasi</label><input type="text" class="form-control" name="mata_pelajaran_sertifikasi" value="{{ $teacher->mata_pelajaran_sertifikasi }}" placeholder="Contoh: Matematika, Bahasa Indonesia"></div>
                    <div class="col-md-3"><label class="form-label">Tahun Sertifikasi</label><input type="number" class="form-control" name="tahun_sertifikasi" value="{{ $teacher->tahun_sertifikasi }}"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-3"><label class="form-label">Upload Sertifikat</label><input type="file" class="form-control" name="file_sertifikat"></div>
                    <div class="col-md-3"><label class="form-label">Inpasing</label><select class="form-control" name="inpasing"><option value="">Pilih</option><option value="Ya" {{ $teacher->inpasing=='Ya'?'selected':'' }}>Ya</option><option value="Tidak" {{ $teacher->inpasing=='Tidak'?'selected':'' }}>Tidak</option></select></div>
                    <div class="col-md-3"><label class="form-label">Nomor Inpasing</label><input type="text" class="form-control" name="nomor_inpasing" value="{{ $teacher->nomor_inpasing }}"></div>
                    <div class="col-md-3"><label class="form-label">Tahun Inpasing</label><input type="number" class="form-control" name="tahun_inpasing" value="{{ $teacher->tahun_inpasing }}"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-3"><label class="form-label">Upload SK Inpasing</label><input type="file" class="form-control" name="file_sk_inpasing"></div>
                    <div class="col-md-4"><label class="form-label">Tunjangan Khusus (jika ada)</label><input type="text" class="form-control" name="tunjangan_khusus" value="{{ $teacher->tunjangan_khusus }}"></div>
                </div>
            </div>
            <!-- Data Akademik -->
            <div class="tab-pane fade" id="akademik" role="tabpanel">
                <div class="row mb-2">
                    <div class="col-md-6">
                        <label class="form-label">Lembaga <span class="text-danger">*</span></label>
                        <select class="form-control" name="institution_id" id="institution_id" required>
                            <option value="">Pilih Lembaga</option>
                            @foreach($institutions as $institution)
                                <option value="{{ $institution->id }}" data-jenjang="{{ $institution->jenis_lembaga }}" {{ $teacher->institution_id==$institution->id?'selected':'' }}>{{ $institution->nama_lembaga }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Tahun Akademik <span class="text-danger">*</span></label>
                        <select class="form-control" name="academic_year_id" required>
                            <option value="">Pilih Tahun Akademik</option>
                            @foreach($academicYears as $academicYear)
                                <option value="{{ $academicYear->id }}" {{ $teacher->academic_year_id == $academicYear->id ? 'selected' : '' }}>{{ $academicYear->tahun_akademik }} - {{ $academicYear->semester }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-3">
                        <label class="form-label">Jenjang <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="jenjang" id="jenjang" readonly required value="{{ $teacher->jenjang ?? '' }}" placeholder="Otomatis dari lembaga">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Tingkat <span class="text-danger">*</span></label>
                        <select class="form-control" name="tingkat" id="tingkat" required>
                            <option value="">Pilih Tingkat</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Kelas <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="kelas" value="{{ $teacher->kelas ?? '' }}" placeholder="Contoh: 7A, 8B, 10 IPA">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Pendidikan Terakhir</label>
                        <input type="text" class="form-control" name="pendidikan_terakhir" value="{{ $teacher->pendidikan_terakhir }}">
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4">
                        <label class="form-label">Nama Perguruan Tinggi</label>
                        <input type="text" class="form-control" name="nama_pt" value="{{ $teacher->nama_pt }}">
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4">
                        <label class="form-label">Program Studi</label>
                        <input type="text" class="form-control" name="program_studi" value="{{ $teacher->program_studi }}">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Tahun Lulus</label>
                        <input type="number" class="form-control" name="tahun_lulus" value="{{ $teacher->tahun_lulus }}">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Upload Ijazah</label>
                        <input type="file" class="form-control" name="file_ijazah">
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-12">
                        <label class="form-label">Riwayat Pendidikan (opsional)</label>
                        <textarea class="form-control" name="riwayat_pendidikan">{{ $teacher->riwayat_pendidikan }}</textarea>
                    </div>
                </div>
                <!-- Mapel Diampu Rangkap 3 -->
                <label class="form-label mt-2">Mata Pelajaran Diampu (Bisa lebih dari satu)</label>
                @php
                    $mapel_diampu = $teacher->mapel_diampu ? json_decode($teacher->mapel_diampu, true) : [];
                    $mapel_jenjang = $teacher->mapel_jenjang ? json_decode($teacher->mapel_jenjang, true) : [];
                    $mapel_tingkat = $teacher->mapel_tingkat ? json_decode($teacher->mapel_tingkat, true) : [];
                    $mapel_kelas = $teacher->mapel_kelas ? json_decode($teacher->mapel_kelas, true) : [];
                    $mapel_jam = $teacher->mapel_jam ? json_decode($teacher->mapel_jam, true) : [];
                @endphp
                @for($i=1;$i<=3;$i++)
                <div class="row mb-2 border rounded p-2 mb-2">
                    <div class="col-md-3">
                        <label class="form-label">Mata Pelajaran #{{ $i }}</label>
                        <input type="text" class="form-control" name="mapel_diampu[{{ $i }}]" value="{{ $mapel_diampu[$i] ?? '' }}" placeholder="Contoh: Matematika">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Jenjang</label>
                        <select class="form-control" name="mapel_jenjang[{{ $i }}]">
                            <option value="">Pilih</option>
                            <option value="SD/MI" {{ ($mapel_jenjang[$i] ?? '')=='SD/MI'?'selected':'' }}>SD/MI</option>
                            <option value="SMP/MTs" {{ ($mapel_jenjang[$i] ?? '')=='SMP/MTs'?'selected':'' }}>SMP/MTs</option>
                            <option value="SMA/MA" {{ ($mapel_jenjang[$i] ?? '')=='SMA/MA'?'selected':'' }}>SMA/MA</option>
                            <option value="SMK" {{ ($mapel_jenjang[$i] ?? '')=='SMK'?'selected':'' }}>SMK</option>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Tingkat</label>
                        <select class="form-control" name="mapel_tingkat[{{ $i }}]">
                            <option value="">Pilih</option>
                            @for($t=1;$t<=12;$t++)<option value="{{ $t }}" {{ ($mapel_tingkat[$i] ?? '')==$t?'selected':'' }}>{{ $t }}</option>@endfor
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Kelas</label>
                        <input type="text" class="form-control" name="mapel_kelas[{{ $i }}]" value="{{ $mapel_kelas[$i] ?? '' }}" placeholder="Contoh: 7A, 10 IPA">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Jumlah Jam/Minggu</label>
                        <input type="number" class="form-control" name="mapel_jam[{{ $i }}]" min="0" value="{{ $mapel_jam[$i] ?? '' }}">
                    </div>
                </div>
                @endfor
                <div class="row mb-2">
                    <div class="col-md-12">
                        <label class="form-label">Riwayat Mengajar (opsional)</label>
                        <textarea class="form-control" name="riwayat_mengajar">{{ $teacher->riwayat_mengajar }}</textarea>
                    </div>
                </div>
                <!-- Mengajar di Tempat Lain -->
                <div class="row mb-2">
                    <div class="col-md-4">
                        <label class="form-label">Mengajar di Tempat Lain?</label>
                        <select class="form-control" name="mengajar_tempat_lain" id="mengajar_tempat_lain">
                            <option value="Tidak" {{ ($teacher->mengajar_tempat_lain ?? '')=='Tidak'?'selected':'' }}>Tidak</option>
                            <option value="Ya" {{ ($teacher->mengajar_tempat_lain ?? '')=='Ya'?'selected':'' }}>Ya</option>
                        </select>
                    </div>
                </div>
                <div id="field-mengajar-lain" style="display:none;">
                    <div class="row mb-2">
                        <div class="col-md-4">
                            <label class="form-label">Nama Lembaga</label>
                            <input type="text" class="form-control" name="nama_lembaga_lain" value="{{ $teacher->nama_lembaga_lain ?? '' }}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Mata Pelajaran</label>
                            <input type="text" class="form-control" name="mapel_lain" value="{{ $teacher->mapel_lain ?? '' }}">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Jumlah Jam Mengajar</label>
                            <input type="number" class="form-control" name="jam_mengajar_lain" min="0" value="{{ $teacher->jam_mengajar_lain ?? '' }}">
                        </div>
                    </div>
                </div>
            </div>
            <!-- Berkas & Arsip Digital -->
            <div class="tab-pane fade" id="arsip" role="tabpanel">
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">KTP</label><input type="file" class="form-control" name="file_ktp"></div>
                    <div class="col-md-4"><label class="form-label">KK</label><input type="file" class="form-control" name="file_kk"></div>
                    <div class="col-md-4"><label class="form-label">Ijazah Terakhir</label><input type="file" class="form-control" name="file_ijazah_terakhir"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Sertifikat Pelatihan</label><input type="file" class="form-control" name="file_sertifikat_pelatihan"></div>
                    <div class="col-md-4"><label class="form-label">SK Pengangkatan</label><input type="file" class="form-control" name="file_sk_pengangkatan"></div>
                    <div class="col-md-4"><label class="form-label">SK Penempatan</label><input type="file" class="form-control" name="file_sk_penempatan"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">SK Inpasing (jika ada)</label><input type="file" class="form-control" name="file_sk_inpasing"></div>
                    <div class="col-md-4"><label class="form-label">Sertifikat Sertifikasi</label><input type="file" class="form-control" name="file_sertifikat_sertifikasi"></div>
                    <div class="col-md-4"><label class="form-label">Berkas Lainnya (opsional)</label><input type="file" class="form-control" name="file_berkas_lain"></div>
                </div>
            </div>
        </div>
        <div class="mt-3">
            <button type="submit" class="btn btn-primary">Update Guru</button>
            <a href="{{ route('teacher.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
@endsection

@push('styles')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<style>
    .nav-tabs .nav-link { font-size: 0.95rem; padding: 0.4rem 1.2rem; }
    .tab-content { background: #fff; border-radius: 0.3rem; box-shadow: 0 1px 4px rgba(0,0,0,0.03); padding: 1.2rem 1.5rem 0.5rem 1.5rem; margin-bottom: 1.5rem; }
    .form-label { font-size: 0.85rem; font-weight: 400; margin-bottom: 0.2rem; }
    .form-control { font-size: 0.95rem; }
    .btn { font-size: 0.95rem; border-radius: 0.2rem; padding: 0.25rem 0.8rem; }
</style>
@endpush

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var tabNav = document.getElementById('teacherTab');
    if (tabNav) {
        tabNav.querySelectorAll('.nav-link').forEach(function(tab) {
            tab.classList.remove('disabled');
            tab.removeAttribute('aria-disabled');
            tab.addEventListener('click', function (e) {
                var tabTrigger = new bootstrap.Tab(tab);
                tabTrigger.show();
            });
        });
    }
});
// Jenjang otomatis dari lembaga
const institutionSelect = document.getElementById('institution_id');
const jenjangInput = document.getElementById('jenjang');
const tingkatSelect = document.getElementById('tingkat');
const tingkatOptions = {
    'SD': [1,2,3,4,5,6],
    'MI': [1,2,3,4,5,6],
    'SMP': [7,8,9],
    'MTs': [7,8,9],
    'SMA': [10,11,12],
    'MA': [10,11,12],
    'SMK': [10,11,12]
};
function updateJenjangTingkat() {
    const selected = institutionSelect.options[institutionSelect.selectedIndex];
    const jenjang = selected.getAttribute('data-jenjang') || '';
    jenjangInput.value = jenjang;
    tingkatSelect.innerHTML = '<option value="">Pilih Tingkat</option>';
    if (tingkatOptions[jenjang]) {
        tingkatOptions[jenjang].forEach(function(t) {
            tingkatSelect.innerHTML += `<option value="${t}" ${t==('{{ $teacher->tingkat ?? '' }}')?'selected':''}>${t}</option>`;
        });
    }
}
institutionSelect.addEventListener('change', updateJenjangTingkat);
document.addEventListener('DOMContentLoaded', updateJenjangTingkat);
// Show/hide field mengajar di tempat lain
const mengajarLain = document.getElementById('mengajar_tempat_lain');
const fieldMengajarLain = document.getElementById('field-mengajar-lain');
function toggleMengajarLain() {
    fieldMengajarLain.style.display = (mengajarLain.value === 'Ya') ? '' : 'none';
}
mengajarLain.addEventListener('change', toggleMengajarLain);
document.addEventListener('DOMContentLoaded', toggleMengajarLain);
</script>
@endpush 