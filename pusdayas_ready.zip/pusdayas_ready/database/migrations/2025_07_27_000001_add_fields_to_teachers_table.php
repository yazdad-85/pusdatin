<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldsToTeachersTable extends Migration
{
    public function up()
    {
        Schema::table('teachers', function (Blueprint $table) {
            if (!Schema::hasColumn('teachers', 'jenjang')) $table->string('jenjang')->nullable()->after('pendidikan_terakhir');
            if (!Schema::hasColumn('teachers', 'tingkat')) $table->string('tingkat')->nullable()->after('jenjang');
            if (!Schema::hasColumn('teachers', 'kelas')) $table->string('kelas')->nullable()->after('tingkat');
            if (!Schema::hasColumn('teachers', 'mapel_jenjang')) $table->text('mapel_jenjang')->nullable()->after('mapel_diampu');
            if (!Schema::hasColumn('teachers', 'mapel_tingkat')) $table->text('mapel_tingkat')->nullable()->after('mapel_jenjang');
            if (!Schema::hasColumn('teachers', 'mapel_kelas')) $table->text('mapel_kelas')->nullable()->after('mapel_tingkat');
            if (!Schema::hasColumn('teachers', 'mapel_jam')) $table->text('mapel_jam')->nullable()->after('mapel_kelas');
            if (!Schema::hasColumn('teachers', 'mengajar_tempat_lain')) $table->string('mengajar_tempat_lain')->nullable()->after('mapel_jam');
            if (!Schema::hasColumn('teachers', 'nama_lembaga_lain')) $table->string('nama_lembaga_lain')->nullable()->after('mengajar_tempat_lain');
            if (!Schema::hasColumn('teachers', 'mapel_lain')) $table->string('mapel_lain')->nullable()->after('nama_lembaga_lain');
            if (!Schema::hasColumn('teachers', 'jam_mengajar_lain')) $table->string('jam_mengajar_lain')->nullable()->after('mapel_lain');
        });
    }
    public function down()
    {
        Schema::table('teachers', function (Blueprint $table) {
            $table->dropColumn([
                'jenjang', 'tingkat', 'kelas',
                'mapel_jenjang', 'mapel_tingkat', 'mapel_kelas', 'mapel_jam',
                'mengajar_tempat_lain', 'nama_lembaga_lain', 'mapel_lain', 'jam_mengajar_lain'
            ]);
        });
    }
} 