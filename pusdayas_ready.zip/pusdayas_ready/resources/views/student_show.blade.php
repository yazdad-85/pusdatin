@extends('layouts.app')
@section('content')
<div class="container">
    <h2 class="mb-4" style="font-size:1.3rem;">Detail Siswa</h2>
    <ul class="nav nav-tabs mb-3 flex-nowrap overflow-auto" id="studentTab" role="tablist" style="white-space:nowrap; gap:0.5rem; font-size:0.95rem;">
      <li class="nav-item" role="presentation" style="flex:1 0 auto; min-width:140px;">
        <button class="nav-link active px-2 py-1" id="pribadi-tab" data-bs-toggle="tab" data-bs-target="#pribadi" type="button" role="tab" aria-controls="pribadi" aria-selected="true" style="font-size:0.95rem;">A. Data Pribadi</button>
      </li>
      <li class="nav-item" role="presentation" style="flex:1 0 auto; min-width:140px;">
        <button class="nav-link px-2 py-1" id="ortu-tab" data-bs-toggle="tab" data-bs-target="#ortu" type="button" role="tab" aria-controls="ortu" aria-selected="false" style="font-size:0.95rem;">B. Data Orang Tua/Wali</button>
      </li>
      <li class="nav-item" role="presentation" style="flex:1 0 auto; min-width:140px;">
        <button class="nav-link px-2 py-1" id="akademik-tab" data-bs-toggle="tab" data-bs-target="#akademik" type="button" role="tab" aria-controls="akademik" aria-selected="false" style="font-size:0.95rem;">C. Data Akademik</button>
      </li>
      <li class="nav-item" role="presentation" style="flex:1 0 auto; min-width:140px;">
        <button class="nav-link px-2 py-1" id="riwayat-tab" data-bs-toggle="tab" data-bs-target="#riwayat" type="button" role="tab" aria-controls="riwayat" aria-selected="false" style="font-size:0.95rem;">D. Riwayat & Arsip</button>
      </li>
      <li class="nav-item" role="presentation" style="flex:1 0 auto; min-width:140px;">
        <button class="nav-link px-2 py-1" id="beasiswa-tab" data-bs-toggle="tab" data-bs-target="#beasiswa" type="button" role="tab" aria-controls="beasiswa" aria-selected="false" style="font-size:0.95rem;">E. Data Beasiswa</button>
      </li>
    </ul>
    <div class="tab-content" id="studentTabContent">
      <!-- Data Pribadi -->
      <div class="tab-pane fade show active" id="pribadi" role="tabpanel" aria-labelledby="pribadi-tab">
        <table class="table table-bordered w-75">
          <tr><th>Nama Lengkap</th><td>{{ $student->nama ?? '-' }}</td></tr>
          <tr><th>NIS</th><td>{{ $student->nis ?? '-' }}</td></tr>
          <tr><th>NISN</th><td>{{ $student->nisn ?? '-' }}</td></tr>
          <tr><th>Jenis Kelamin</th><td>{{ $student->jenis_kelamin ?? '-' }}</td></tr>
          <tr><th>Tempat Lahir</th><td>{{ $student->tempat_lahir ?? '-' }}</td></tr>
          <tr><th>Tanggal Lahir</th><td>{{ $student->tanggal_lahir ?? '-' }}</td></tr>
          <tr><th>Agama</th><td>{{ $student->agama ?? '-' }}</td></tr>
          <tr><th>Alamat Lengkap</th><td>{{ $student->alamat ?? '-' }}</td></tr>
          <tr><th>Nomor HP Siswa</th><td>{{ $student->telepon ?? '-' }}</td></tr>
        </table>
      </div>
      <!-- Data Orang Tua/Wali -->
      <div class="tab-pane fade" id="ortu" role="tabpanel" aria-labelledby="ortu-tab">
        <table class="table table-bordered w-75">
          <tr><th>Nama Ayah</th><td>{{ $student->nama_ayah ?? '-' }}</td></tr>
          <tr><th>Pekerjaan Ayah</th><td>{{ $student->pekerjaan_ayah ?? '-' }}</td></tr>
          <tr><th>Pendidikan Ayah</th><td>{{ $student->pendidikan_ayah ?? '-' }}</td></tr>
          <tr><th>Nama Ibu</th><td>{{ $student->nama_ibu ?? '-' }}</td></tr>
          <tr><th>Pekerjaan Ibu</th><td>{{ $student->pekerjaan_ibu ?? '-' }}</td></tr>
          <tr><th>Pendidikan Ibu</th><td>{{ $student->pendidikan_ibu ?? '-' }}</td></tr>
          <tr><th>Nama Wali</th><td>{{ $student->nama_wali ?? '-' }}</td></tr>
          <tr><th>Pekerjaan Wali</th><td>{{ $student->pekerjaan_wali ?? '-' }}</td></tr>
          <tr><th>Nomor HP Orang Tua/Wali</th><td>{{ $student->telepon_wali ?? '-' }}</td></tr>
          <tr><th>Penghasilan Orang Tua/Wali</th><td>{{ $student->penghasilan ?? '-' }}</td></tr>
        </table>
      </div>
      <!-- Data Akademik -->
      <div class="tab-pane fade" id="akademik" role="tabpanel" aria-labelledby="akademik-tab">
        <table class="table table-bordered w-75">
          <tr><th>Lembaga</th><td>{{ $student->institution ? $student->institution->nama_lembaga : '-' }}</td></tr>
          <tr><th>Tahun Akademik</th><td>{{ $student->academicYear ? $student->academicYear->tahun_akademik . ' - ' . $student->academicYear->semester : '-' }}</td></tr>
          <tr><th>Jenjang</th><td>{{ $student->jenjang ?? '-' }}</td></tr>
          <tr><th>Tingkat</th><td>{{ $student->tingkat ?? '-' }}</td></tr>
          <tr><th>Kelas Saat Ini</th><td>{{ $student->kelas ?? '-' }}</td></tr>
          <tr><th>Tahun Masuk</th><td>{{ $student->tahun_masuk ?? '-' }}</td></tr>
          <tr><th>Status</th><td>{{ $student->status ?? '-' }}</td></tr>
          <tr><th>Asal Sekolah</th><td>{{ $student->asal_sekolah ?? '-' }}</td></tr>
          <tr><th>Jurusan</th><td>{{ $student->jurusan ?? '-' }}</td></tr>
        </table>
      </div>
      <!-- Riwayat dan Arsip -->
      <div class="tab-pane fade" id="riwayat" role="tabpanel" aria-labelledby="riwayat-tab">
        <table class="table table-bordered w-75">
          <tr><th>Riwayat Pendidikan Sebelumnya</th><td>{{ $student->riwayat_pendidikan_sebelumnya ?? '-' }}</td></tr>
          <tr><th>Riwayat Pendidikan</th><td>{{ $student->riwayat_pendidikan ?? '-' }}</td></tr>
          <tr><th>Prestasi Akademik / Non-akademik</th><td>{{ $student->prestasi ?? '-' }}</td></tr>
          <tr><th>Lulus Ke Mana?</th><td>{{ $student->lulus_ke ?? '-' }}</td></tr>
          <tr><th>Akta Kelahiran</th><td>{{ $student->akta_kelahiran ?? '-' }}</td></tr>
          <tr><th>Kartu Keluarga</th><td>{{ $student->kartu_keluarga ?? '-' }}</td></tr>
          <tr><th>KIP/KKS/Kartu Perlindungan Sosial</th><td>{{ $student->kartu_kip ?? '-' }}</td></tr>
          <tr><th>Ijazah SMP/SD</th><td>{{ $student->ijazah ?? '-' }}</td></tr>
          <tr><th>Surat Pindah (jika ada)</th><td>{{ $student->surat_pindah ?? '-' }}</td></tr>
        </table>
      </div>
      <!-- Data Beasiswa -->
      <div class="tab-pane fade" id="beasiswa" role="tabpanel" aria-labelledby="beasiswa-tab">
        <table class="table table-bordered w-75">
          <tr><th>Apakah menerima beasiswa?</th><td>{{ $student->beasiswa ?? '-' }}</td></tr>
          <tr><th>Jenis Beasiswa</th><td>{{ $student->jenis_beasiswa ?? '-' }}</td></tr>
          <tr><th>Periode Beasiswa</th><td>{{ $student->periode_beasiswa ?? '-' }}</td></tr>
          <tr><th>Keterangan Tambahan</th><td>{{ $student->keterangan_beasiswa ?? '-' }}</td></tr>
        </table>
      </div>
    </div>
    <a href="{{ route('student.index') }}" class="btn btn-secondary btn-sm mt-3">Kembali</a>
</div>
@endsection

@push('styles')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<style>
    .nav-tabs .nav-link {
        font-size: 0.95rem;
        padding: 0.4rem 1.2rem;
    }
    .tab-content {
        background: #fff;
        border-radius: 0.3rem;
        box-shadow: 0 1px 4px rgba(0,0,0,0.03);
        padding: 1.2rem 1.5rem 0.5rem 1.5rem;
        margin-bottom: 1.5rem;
    }
    .form-label {
        font-size: 0.85rem;
        font-weight: 400;
        margin-bottom: 0.2rem;
    }
    .form-control-xs {
        font-size: 0.85rem;
        padding: 0.2rem 0.5rem;
        border-radius: 0.2rem;
        height: 1.7rem;
    }
    .btn {
        font-size: 0.85rem;
        border-radius: 0.2rem;
        padding: 0.25rem 0.8rem;
    }
</style>
@endpush

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
  var tabNav = document.getElementById('studentTab');
  if (tabNav) {
    tabNav.querySelectorAll('.nav-link').forEach(function(tab) {
      tab.classList.remove('disabled');
      tab.removeAttribute('aria-disabled');
      tab.addEventListener('click', function (e) {
        var tabTrigger = new bootstrap.Tab(tab);
        tabTrigger.show();
      });
    });
  }
});
</script>
@endpush 