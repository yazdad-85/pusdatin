<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Tambah Karyawan</h2>
    <form method="POST" action="<?php echo e(route('employee.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <ul class="nav nav-tabs mb-3" id="empTab" role="tablist">
            <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#pribadi" type="button" role="tab">A. Data Pribadi</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#kategori" type="button" role="tab">B. Kategori & Jabatan</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#kepegawaian" type="button" role="tab">C. Data Kepegawaian</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#akademik" type="button" role="tab">D. Akademik & Pelatihan</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#arsip" type="button" role="tab">E. Berkas & Arsip</button></li>
        </ul>
        <div class="tab-content" id="empTabContent">
            <!-- Data Pribadi -->
            <div class="tab-pane fade show active" id="pribadi" role="tabpanel">
                <div class="row mb-2">
                    <div class="col-md-6"><label class="form-label">Nama Lengkap</label><input type="text" name="nama_lengkap" class="form-control <?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nama_lengkap')); ?>" required><?php $__errorArgs = ['nama_lengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="col-md-3"><label class="form-label">NIK</label><input type="text" name="nik" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nik')); ?>" required><?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                    <div class="col-md-3"><label class="form-label">Tempat Lahir</label><input type="text" name="tempat_lahir" class="form-control" value="<?php echo e(old('tempat_lahir')); ?>"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Tanggal Lahir</label><input type="date" name="tanggal_lahir" class="form-control" value="<?php echo e(old('tanggal_lahir')); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Jenis Kelamin</label><select name="jenis_kelamin" class="form-control"><option value="">Pilih</option><option value="Laki-laki">Laki-laki</option><option value="Perempuan">Perempuan</option></select></div>
                    <div class="col-md-4"><label class="form-label">Agama</label><input type="text" name="agama" class="form-control" value="<?php echo e(old('agama')); ?>"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-8"><label class="form-label">Alamat Lengkap</label><input type="text" name="alamat" class="form-control" value="<?php echo e(old('alamat')); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Nomor HP</label><input type="text" name="telepon" class="form-control" value="<?php echo e(old('telepon')); ?>"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-6"><label class="form-label">Email (opsional)</label><input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>"></div>
                    <div class="col-md-6"><label class="form-label">Foto Karyawan (upload)</label><input type="file" name="foto" class="form-control"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Status Pernikahan</label><input type="text" name="status_pernikahan" class="form-control" value="<?php echo e(old('status_pernikahan')); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Pendidikan Terakhir</label><input type="text" name="pendidikan_terakhir" class="form-control" value="<?php echo e(old('pendidikan_terakhir')); ?>"></div>
                </div>
            </div>
            <!-- Kategori & Jabatan -->
            <div class="tab-pane fade" id="kategori" role="tabpanel">
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Kategori Karyawan</label><select name="employee_category_id" class="form-control" required><option value="">Pilih Kategori</option><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nama_kategori); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                    <div class="col-md-4"><label class="form-label">Unit Kerja / Lembaga</label><select name="institution_id" class="form-control"><option value="">Pilih Lembaga</option><?php $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($inst->id); ?>"><?php echo e($inst->nama_lembaga); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                    <div class="col-md-4"><label class="form-label">Tahun Akademik</label><select name="academic_year_id" class="form-control"><option value="">Pilih Tahun Akademik</option><?php $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academicYear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($academicYear->id); ?>"><?php echo e($academicYear->tahun_akademik); ?> - <?php echo e($academicYear->semester); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-6"><label class="form-label">Jabatan / Fungsi</label><input type="text" name="jabatan" class="form-control" value="<?php echo e(old('jabatan')); ?>"></div>
                    <div class="col-md-6"><label class="form-label">Keterangan Tugas Tambahan (opsional)</label><input type="text" name="tugas_tambahan" class="form-control" value="<?php echo e(old('tugas_tambahan')); ?>"></div>
                </div>
            </div>
            <!-- Data Kepegawaian -->
            <div class="tab-pane fade" id="kepegawaian" role="tabpanel">
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Status Pegawai</label><select name="status_pegawai" class="form-control"><option value="">Pilih</option><option value="Tetap">Tetap</option><option value="Kontrak Yayasan">Kontrak Yayasan</option></select></div>
                    <div class="col-md-4"><label class="form-label">Nomor SK Pengangkatan</label><input type="text" name="nomor_sk" class="form-control" value="<?php echo e(old('nomor_sk')); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Tanggal Mulai Tugas (TMT)</label><input type="date" name="tmt" class="form-control" value="<?php echo e(old('tmt')); ?>"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Masa Kerja (tahun)</label><input type="number" name="masa_kerja" class="form-control" value="<?php echo e(old('masa_kerja')); ?>" min="0"></div>
                    <div class="col-md-4"><label class="form-label">Jenis Kontrak</label><select name="jenis_kontrak" class="form-control"><option value="">Pilih</option><option value="Tetap">Tetap</option><option value="Tidak Tetap">Tidak Tetap</option></select></div>
                    <div class="col-md-4"><label class="form-label">Status</label><select name="status" class="form-control"><option value="Aktif">Aktif</option><option value="Tidak Aktif">Tidak Aktif</option></select></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-6"><label class="form-label">Keterangan Pensiun / Berhenti (opsional)</label><input type="text" name="keterangan_pensiun" class="form-control" value="<?php echo e(old('keterangan_pensiun')); ?>"></div>
                </div>
            </div>
            <!-- Akademik & Pelatihan -->
            <div class="tab-pane fade" id="akademik" role="tabpanel">
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Pendidikan Terakhir (Jenjang)</label><input type="text" name="jenjang_pendidikan" class="form-control" value="<?php echo e(old('jenjang_pendidikan')); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Nama Sekolah/PT</label><input type="text" name="nama_pt" class="form-control" value="<?php echo e(old('nama_pt')); ?>"></div>
                    <div class="col-md-4"><label class="form-label">Tahun Lulus</label><input type="number" name="tahun_lulus" class="form-control" value="<?php echo e(old('tahun_lulus')); ?>"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-6"><label class="form-label">Ijazah (upload)</label><input type="file" name="file_ijazah" class="form-control"></div>
                </div>
                <hr>
                <label class="form-label">Riwayat Pelatihan (bisa lebih dari satu)</label>
                <div id="pelatihan-list">
                    <div class="row mb-2 pelatihan-item">
                        <div class="col-md-4"><input type="text" name="riwayat_pelatihan[0][nama]" class="form-control" placeholder="Nama Pelatihan"></div>
                        <div class="col-md-2"><input type="number" name="riwayat_pelatihan[0][tahun]" class="form-control" placeholder="Tahun"></div>
                        <div class="col-md-4"><input type="file" name="riwayat_pelatihan[0][file]" class="form-control"></div>
                        <div class="col-md-2 d-flex align-items-center"><button type="button" class="btn btn-danger btn-sm remove-pelatihan" style="display:none;"><i class="fas fa-trash"></i></button></div>
                    </div>
                </div>
                <button type="button" class="btn btn-outline-success btn-sm" id="add-pelatihan"><i class="fas fa-plus"></i> Tambah Pelatihan</button>
            </div>
            <!-- Berkas & Arsip Digital -->
            <div class="tab-pane fade" id="arsip" role="tabpanel">
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">KTP</label><input type="file" name="file_ktp" class="form-control"></div>
                    <div class="col-md-4"><label class="form-label">KK</label><input type="file" name="file_kk" class="form-control"></div>
                    <div class="col-md-4"><label class="form-label">Ijazah Terakhir</label><input type="file" name="file_ijazah_terakhir" class="form-control"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">SK Pengangkatan</label><input type="file" name="file_sk_pengangkatan" class="form-control"></div>
                    <div class="col-md-4"><label class="form-label">SK Penugasan</label><input type="file" name="file_sk_penugasan" class="form-control"></div>
                    <div class="col-md-4"><label class="form-label">Sertifikat Pelatihan</label><input type="file" name="file_sertifikat_pelatihan" class="form-control"></div>
                </div>
                <div class="row mb-2">
                    <div class="col-md-4"><label class="form-label">Surat Perjanjian Kerja</label><input type="file" name="file_perjanjian_kerja" class="form-control"></div>
                    <div class="col-md-4"><label class="form-label">Dokumen Tambahan (opsional)</label><input type="file" name="file_dokumen_tambahan" class="form-control"></div>
                </div>
            </div>
        </div>
        <div class="mt-3">
            <button type="submit" class="btn btn-primary">Simpan Data Karyawan</button>
            <a href="<?php echo e(route('employee')); ?>" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
let pelatihanIdx = 1;
document.getElementById('add-pelatihan').onclick = function() {
    const list = document.getElementById('pelatihan-list');
    const item = document.createElement('div');
    item.className = 'row mb-2 pelatihan-item';
    item.innerHTML = `<div class="col-md-4"><input type="text" name="riwayat_pelatihan[${pelatihanIdx}][nama]" class="form-control" placeholder="Nama Pelatihan"></div>
        <div class="col-md-2"><input type="number" name="riwayat_pelatihan[${pelatihanIdx}][tahun]" class="form-control" placeholder="Tahun"></div>
        <div class="col-md-4"><input type="file" name="riwayat_pelatihan[${pelatihanIdx}][file]" class="form-control"></div>
        <div class="col-md-2 d-flex align-items-center"><button type="button" class="btn btn-danger btn-sm remove-pelatihan"><i class="fas fa-trash"></i></button></div>`;
    list.appendChild(item);
    pelatihanIdx++;
    updateRemoveButtons();
};
function updateRemoveButtons() {
    document.querySelectorAll('.remove-pelatihan').forEach(btn => {
        btn.style.display = '';
        btn.onclick = function() {
            btn.closest('.pelatihan-item').remove();
        };
    });
    // Hanya tampilkan tombol hapus jika lebih dari satu pelatihan
    if(document.querySelectorAll('.pelatihan-item').length === 1) {
        document.querySelector('.remove-pelatihan').style.display = 'none';
    }
}
document.addEventListener('DOMContentLoaded', updateRemoveButtons);
</script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mbp19/Documents/YAZDAD/APLIKASI PLAN/pusdayas/resources/views/employee/create.blade.php ENDPATH**/ ?>