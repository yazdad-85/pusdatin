@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Ekspor ke Excel</h1>
    <p>Halaman ini akan digunakan untuk ekspor data ke Excel.</p>
</div>
@endsection