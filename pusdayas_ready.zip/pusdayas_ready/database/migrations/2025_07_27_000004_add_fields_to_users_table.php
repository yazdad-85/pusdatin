<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldsToUsersTable extends Migration
{
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->enum('role', ['superadmin', 'admin_lembaga'])->default('admin_lembaga')->after('password');
            $table->unsignedBigInteger('institution_id')->nullable()->after('role');
            $table->enum('status', ['Aktif', 'Tidak Aktif'])->default('Aktif')->after('institution_id');
            $table->string('foto')->nullable()->after('status');
            $table->foreign('institution_id')->references('id')->on('institutions')->onDelete('set null');
        });
    }
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropForeign(['institution_id']);
            $table->dropColumn(['role', 'institution_id', 'status', 'foto']);
        });
    }
} 