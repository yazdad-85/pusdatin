<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Kategori Karyawan</h2>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <a href="<?php echo e(route('employee-categories.create')); ?>" class="btn btn-primary mb-3"><i class="fas fa-plus"></i> Tambah Kategori</a>
    <div class="table-responsive">
        <table class="table table-bordered align-middle">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Kategori</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($cat->nama_kategori); ?></td>
                    <td><?php echo e($cat->keterangan); ?></td>
                    <td>
                        <a href="<?php echo e(route('employee-categories.edit', $cat->id)); ?>" class="btn btn-sm btn-warning"><i class="fas fa-pen"></i></a>
                        <form action="<?php echo e(route('employee-categories.destroy', $cat->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin hapus?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="text-center">Belum ada kategori.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mbp19/Documents/YAZDAD/APLIKASI PLAN/pusdayas/resources/views/employee_categories/index.blade.php ENDPATH**/ ?>