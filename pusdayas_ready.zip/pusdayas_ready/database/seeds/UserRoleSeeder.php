<?php

use Illuminate\Database\Seeder;
use App\User;

class UserRoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Set superadmin
        User::where('email', 'superadmin@example.com')->update(['role' => 'superadmin']);
        
        // Set admin_lembaga untuk user lain
        User::where('email', '!=', 'superadmin@example.com')->update(['role' => 'admin_lembaga']);
        
        echo "User roles updated successfully!\n";
    }
}
