@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">
                        <i class="fas fa-eye text-primary"></i>
                        Detail Tahun Akademik
                    </h4>
                    <div>
                        <a href="{{ route('academic-year.edit', $academicYear->id) }}" class="btn btn-warning">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="{{ route('academic-year.index') }}" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Kembali
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td width="40%"><strong><i class="fas fa-calendar text-primary"></i> Tahun Akademik</strong></td>
                                    <td width="5%">:</td>
                                    <td>{{ $academicYear->tahun_akademik }}</td>
                                </tr>
                                <tr>
                                    <td><strong><i class="fas fa-graduation-cap text-primary"></i> Semester</strong></td>
                                    <td>:</td>
                                    <td>
                                        <span class="badge bg-{{ $academicYear->semester == 'Ganjil' ? 'primary' : 'success' }}">
                                            {{ $academicYear->semester }}
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong><i class="fas fa-calendar-day text-primary"></i> Tanggal Mulai</strong></td>
                                    <td>:</td>
                                    <td>{{ \Carbon\Carbon::parse($academicYear->tanggal_mulai)->format('d F Y') }}</td>
                                </tr>
                                <tr>
                                    <td><strong><i class="fas fa-calendar-check text-primary"></i> Tanggal Selesai</strong></td>
                                    <td>:</td>
                                    <td>{{ \Carbon\Carbon::parse($academicYear->tanggal_selesai)->format('d F Y') }}</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-borderless">
                                <tr>
                                    <td width="40%"><strong><i class="fas fa-toggle-on text-primary"></i> Status</strong></td>
                                    <td width="5%">:</td>
                                    <td>
                                        @if($academicYear->status == 'aktif')
                                            <span class="badge bg-success">
                                                <i class="fas fa-check-circle"></i> Aktif
                                            </span>
                                        @else
                                            <span class="badge bg-secondary">
                                                <i class="fas fa-times-circle"></i> Nonaktif
                                            </span>
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong><i class="fas fa-sticky-note text-primary"></i> Keterangan</strong></td>
                                    <td>:</td>
                                    <td>{{ $academicYear->keterangan ?: '-' }}</td>
                                </tr>
                                <tr>
                                    <td><strong><i class="fas fa-clock text-primary"></i> Dibuat</strong></td>
                                    <td>:</td>
                                    <td>{{ \Carbon\Carbon::parse($academicYear->created_at)->format('d F Y H:i') }}</td>
                                </tr>
                                <tr>
                                    <td><strong><i class="fas fa-edit text-primary"></i> Diperbarui</strong></td>
                                    <td>:</td>
                                    <td>{{ \Carbon\Carbon::parse($academicYear->updated_at)->format('d F Y H:i') }}</td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <hr>

                    <div class="row">
                        <div class="col-12">
                            <h5 class="mb-3">
                                <i class="fas fa-chart-bar text-primary"></i>
                                Statistik Data Terkait
                            </h5>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="card bg-primary text-white">
                                        <div class="card-body text-center">
                                            <i class="fas fa-user-graduate fa-2x mb-2"></i>
                                            <h4>{{ $academicYear->students()->count() }}</h4>
                                            <p class="mb-0">Siswa</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card bg-success text-white">
                                        <div class="card-body text-center">
                                            <i class="fas fa-chalkboard-teacher fa-2x mb-2"></i>
                                            <h4>{{ $academicYear->teachers()->count() }}</h4>
                                            <p class="mb-0">Guru</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card bg-info text-white">
                                        <div class="card-body text-center">
                                            <i class="fas fa-user-tie fa-2x mb-2"></i>
                                            <h4>{{ $academicYear->employees()->count() }}</h4>
                                            <p class="mb-0">Karyawan</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 