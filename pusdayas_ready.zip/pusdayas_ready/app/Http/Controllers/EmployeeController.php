<?php
namespace App\Http\Controllers;
use App\Employee;
use App\EmployeeCategory;
use App\Institution;
use App\AcademicYear;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
class EmployeeController extends Controller
{
    public function index(Request $request) {
        $categories = EmployeeCategory::all();
        $institutions = Institution::all();
        $query = Employee::query();
        if ($request->filled('employee_category_id')) $query->where('employee_category_id', $request->employee_category_id);
        if ($request->filled('institution_id')) $query->where('institution_id', $request->institution_id);
        if ($request->filled('q')) {
            $q = $request->q;
            $query->where(function($sub) use ($q) {
                $sub->where('nama_lengkap','like',"%$q%")
                    ->orWhere('nik','like',"%$q%")
                    ->orWhere('telepon','like',"%$q%")
                    ->orWhere('email','like',"%$q%")
                    ->orWhere('alamat','like',"%$q%")
                ;
            });
        }
        $employees = $query->with(['category','institution'])->orderBy('nama_lengkap')->paginate(15)->appends($request->except('page'));
        return view('employee.index', compact('employees','categories','institutions'));
    }
    public function create() {
        $categories = EmployeeCategory::all();
        $institutions = Institution::all();
        $academicYears = AcademicYear::all();
        return view('employee.create', compact('categories','institutions','academicYears'));
    }
    public function store(Request $request) {
        $request->validate([
            'nama_lengkap'=>'required',
            'nik'=>'required|unique:employees,nik',
            'employee_category_id'=>'required',
        ]);
        $data = $request->except(['_token','_method','foto','file_ktp','file_kk','file_ijazah_terakhir','file_sk_pengangkatan','file_sk_penugasan','file_sertifikat_pelatihan','file_perjanjian_kerja','file_dokumen_tambahan']);
        // Upload file
        $folder = 'public/karyawan/'.($request->nik ?: uniqid());
        foreach(['foto','file_ktp','file_kk','file_ijazah_terakhir','file_sk_pengangkatan','file_sk_penugasan','file_sertifikat_pelatihan','file_perjanjian_kerja','file_dokumen_tambahan'] as $field) {
            if($request->hasFile($field)) {
                $file = $request->file($field);
                $filename = $field.'_'.time().'.'.$file->getClientOriginalExtension();
                $path = $file->storeAs($folder, $filename);
                $data[$field] = str_replace('public/','',$path);
            }
        }
        // Riwayat pelatihan (array)
        if($request->has('riwayat_pelatihan')) {
            $data['riwayat_pelatihan'] = json_encode($request->riwayat_pelatihan);
        }
        Employee::create($data);
        return redirect()->route('employee.index')->with('success','Data karyawan berhasil ditambah');
    }
    public function show($id) {
        $employee = Employee::with(['category','institution'])->findOrFail($id);
        return view('employee.show', compact('employee'));
    }
    public function edit($id) {
        $employee = Employee::findOrFail($id);
        $categories = EmployeeCategory::all();
        $institutions = Institution::all();
        $academicYears = AcademicYear::all();
        return view('employee.edit', compact('employee','categories','institutions','academicYears'));
    }
    public function update(Request $request, $id) {
        $employee = Employee::findOrFail($id);
        $request->validate([
            'nama_lengkap'=>'required',
            'nik'=>'required|unique:employees,nik,'.$id,
            'employee_category_id'=>'required',
        ]);
        $data = $request->except(['_token','_method','foto','file_ktp','file_kk','file_ijazah_terakhir','file_sk_pengangkatan','file_sk_penugasan','file_sertifikat_pelatihan','file_perjanjian_kerja','file_dokumen_tambahan']);
        $folder = 'public/karyawan/'.($request->nik ?: $employee->nik ?: $employee->id);
        foreach(['foto','file_ktp','file_kk','file_ijazah_terakhir','file_sk_pengangkatan','file_sk_penugasan','file_sertifikat_pelatihan','file_perjanjian_kerja','file_dokumen_tambahan'] as $field) {
            if($request->hasFile($field)) {
                $file = $request->file($field);
                $filename = $field.'_'.time().'.'.$file->getClientOriginalExtension();
                $path = $file->storeAs($folder, $filename);
                $data[$field] = str_replace('public/','',$path);
            }
        }
        if($request->has('riwayat_pelatihan')) {
            $data['riwayat_pelatihan'] = json_encode($request->riwayat_pelatihan);
        }
        $employee->update($data);
        return redirect()->route('employee.index')->with('success','Data karyawan berhasil diupdate');
    }
    public function destroy($id) {
        $employee = Employee::findOrFail($id);
        $employee->delete();
        return redirect()->route('employee.index')->with('success','Data karyawan berhasil dihapus');
    }
}
