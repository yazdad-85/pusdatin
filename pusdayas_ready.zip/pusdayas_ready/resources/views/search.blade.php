@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Pencarian & Filter Data</h1>
    <p>Halaman ini akan digunakan untuk pencarian dan filter data.</p>
</div>
@endsection