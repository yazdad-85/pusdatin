@extends('layouts.app')

@section('content')
<div class="container">
    <h1>File Dokumen Siswa</h1>
    <p>Halaman ini akan menampilkan daftar file arsip siswa.</p>
</div>
@endsection