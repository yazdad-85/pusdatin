<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{
    protected $fillable = [
        'nama_lengkap', 'nik', 'nuptk', 'tempat_lahir', 'tanggal_lahir', 'jenis_kelamin', 'agama', 'alamat', 'status_pernikahan', 'telepon', 'status', 'email', 'foto',
        'status_kepegawaian', 'tmt', 'sk_pengangkatan', 'nomor_sk', 'instansi_pengangkat', 'pangkat_golongan', 'gaji_pokok',
        'sertifikasi_guru', 'nomor_sertifikat', 'mata_pelajaran_sertifikasi', 'tahun_sertifikasi', 'file_sertifikat', 'inpasing', 'nomor_inpasing', 'tahun_inpasing', 'file_sk_inpasing', 'tunjangan_khusus',
        'pendidikan_terakhir', 'jenjang_pendidikan', 'nama_pt', 'program_studi', 'tahun_lulus', 'file_ijazah', 'riwayat_pendidikan', 'riwayat_mengajar', 'mapel_diampu', 'jenjang_mapel', 'jam_mengajar',
        'file_ktp', 'file_kk', 'file_ijazah_terakhir', 'file_sertifikat_pelatihan', 'file_sk_pengangkatan', 'file_sk_penempatan', 'file_sertifikat_sertifikasi', 'file_berkas_lain',
        'institution_id',
        'jenjang', 'tingkat', 'kelas',
        'mengajar_tempat_lain', 'nama_lembaga_lain', 'mapel_lain', 'jam_mengajar_lain',
        'academic_year_id',
    ];
    protected $casts = [
        'mapel_diampu' => 'array',
        'mapel_jenjang' => 'array',
        'mapel_tingkat' => 'array',
        'mapel_kelas' => 'array',
        'mapel_jam' => 'array',
    ];

    public function institution()
    {
        return $this->belongsTo(Institution::class);
    }

    public function academicYear()
    {
        return $this->belongsTo(AcademicYear::class);
    }
}
