<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>File Dokumen Karyawan</h1>
    <p>Halaman ini akan menampilkan daftar file arsip karyawan.</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mbp19/Documents/YAZDAD/APLIKASI PLAN/pusdayas/resources/views/archives/employees.blade.php ENDPATH**/ ?>