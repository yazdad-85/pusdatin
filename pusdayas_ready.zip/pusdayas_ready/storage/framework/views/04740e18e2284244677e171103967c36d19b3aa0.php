<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">
                        <i class="fas fa-calendar-alt text-primary"></i>
                        Manajemen Tahun Akademik
                    </h4>
                    <a href="<?php echo e(route('academic-year.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Tambah Tahun Akademik
                    </a>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-circle"></i> <?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-hover table-bordered align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th width="20%">Tahun Akademik</th>
                                    <th width="15%">Semester</th>
                                    <th width="15%">Periode</th>
                                    <th width="10%">Status</th>
                                    <th width="20%">Keterangan</th>
                                    <th width="15%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $academicYear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center"><?php echo e($index + 1 + ($academicYears->currentPage() - 1) * $academicYears->perPage()); ?></td>
                                    <td>
                                        <strong><?php echo e($academicYear->tahun_akademik); ?></strong>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($academicYear->semester == 'Ganjil' ? 'primary' : 'success'); ?>">
                                            <?php echo e($academicYear->semester); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($academicYear->tanggal_mulai)->format('d/m/Y')); ?> - 
                                        <?php echo e(\Carbon\Carbon::parse($academicYear->tanggal_selesai)->format('d/m/Y')); ?>

                                    </td>
                                    <td class="text-center">
                                        <?php if($academicYear->status == 'aktif'): ?>
                                            <span class="badge bg-success">
                                                <i class="fas fa-check-circle"></i> Aktif
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">
                                                <i class="fas fa-times-circle"></i> Nonaktif
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($academicYear->keterangan ?: '-'); ?>

                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('academic-year.show', $academicYear->id)); ?>" 
                                               class="btn btn-info btn-sm" 
                                               title="Detail">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('academic-year.edit', $academicYear->id)); ?>" 
                                               class="btn btn-warning btn-sm" 
                                               title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('academic-year.destroy', $academicYear->id)); ?>" 
                                                  method="POST" 
                                                  class="d-inline"
                                                  onsubmit="return confirm('Yakin ingin menghapus tahun akademik ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" title="Hapus">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="fas fa-calendar-times fa-3x mb-3"></i>
                                            <p class="mb-0">Belum ada data tahun akademik</p>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex justify-content-center">
                        <?php echo e($academicYears->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mbp19/Documents/YAZDAD/APLIKASI PLAN/pusdayas/resources/views/academic_year/index.blade.php ENDPATH**/ ?>