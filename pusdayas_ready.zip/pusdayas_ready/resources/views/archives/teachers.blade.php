@extends('layouts.app')

@section('content')
<div class="container">
    <h1>File Dokumen Guru</h1>
    <p>Halaman ini akan menampilkan daftar file arsip guru.</p>
</div>
@endsection