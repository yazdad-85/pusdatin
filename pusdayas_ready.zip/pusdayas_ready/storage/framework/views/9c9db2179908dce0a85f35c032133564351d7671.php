<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Tambah Akun</h2>
    <form method="POST" action="<?php echo e(route('user.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row mb-2">
            <div class="col-md-4">
                <label class="form-label">Nama</label>
                <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-4">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-4">
                <label class="form-label">Password (default)</label>
                <input type="text" class="form-control" value="123456" readonly>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-md-4">
                <label class="form-label">Role</label>
                <select name="role" class="form-control" id="role-select" required>
                    <option value="">Pilih Role</option>
                    <option value="superadmin" <?php echo e(old('role')=='superadmin'?'selected':''); ?>>Superadmin</option>
                    <option value="admin_lembaga" <?php echo e(old('role')=='admin_lembaga'?'selected':''); ?>>Admin Lembaga</option>
                </select>
            </div>
            <div class="col-md-4" id="lembaga-field">
                <label class="form-label">Lembaga</label>
                <select name="institution_id" class="form-control">
                    <option value="">Pilih Lembaga</option>
                    <?php $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($inst->id); ?>" <?php echo e(old('institution_id')==$inst->id?'selected':''); ?>><?php echo e($inst->nama_lembaga); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Status</label>
                <select name="status" class="form-control">
                    <option value="Aktif" <?php echo e(old('status')=='Aktif'?'selected':''); ?>>Aktif</option>
                    <option value="Tidak Aktif" <?php echo e(old('status')=='Tidak Aktif'?'selected':''); ?>>Tidak Aktif</option>
                </select>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-md-4">
                <label class="form-label">Foto Profil (opsional)</label>
                <input type="file" name="foto" class="form-control">
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
const roleSelect = document.getElementById('role-select');
const lembagaField = document.getElementById('lembaga-field');
const lembagaSelect = lembagaField.querySelector('select');

function toggleLembagaField() {
    if (roleSelect.value === 'admin_lembaga') {
        lembagaField.style.display = '';
        lembagaSelect.required = true;
    } else {
        lembagaField.style.display = 'none';
        lembagaSelect.required = false;
        lembagaSelect.value = '';
    }
}

roleSelect.addEventListener('change', toggleLembagaField);
document.addEventListener('DOMContentLoaded', toggleLembagaField);
</script>
<?php $__env->stopPush(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mbp19/Documents/YAZDAD/APLIKASI PLAN/pusdayas/resources/views/user/create.blade.php ENDPATH**/ ?>