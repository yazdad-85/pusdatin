@extends('layouts.app')
@section('content')
<div class="container">
    <h2 class="mb-4" style="font-size:1.3rem;">Detail Guru</h2>
    <ul class="nav nav-tabs mb-3 flex-nowrap overflow-auto" id="teacherTab" role="tablist" style="white-space:nowrap; gap:0.5rem; font-size:0.95rem;">
        <li class="nav-item" role="presentation"><button class="nav-link active" id="pribadi-tab" data-bs-toggle="tab" data-bs-target="#pribadi" type="button" role="tab">A. Data Pribadi</button></li>
        <li class="nav-item" role="presentation"><button class="nav-link" id="kepegawaian-tab" data-bs-toggle="tab" data-bs-target="#kepegawaian" type="button" role="tab">B. Data Kepegawaian</button></li>
        <li class="nav-item" role="presentation"><button class="nav-link" id="khusus-tab" data-bs-toggle="tab" data-bs-target="#khusus" type="button" role="tab">C. Status Khusus</button></li>
        <li class="nav-item" role="presentation"><button class="nav-link" id="akademik-tab" data-bs-toggle="tab" data-bs-target="#akademik" type="button" role="tab">D. Data Akademik</button></li>
        <li class="nav-item" role="presentation"><button class="nav-link" id="arsip-tab" data-bs-toggle="tab" data-bs-target="#arsip" type="button" role="tab">E. Berkas & Arsip</button></li>
    </ul>
    <div class="tab-content" id="teacherTabContent">
        <!-- Data Pribadi -->
        <div class="tab-pane fade show active" id="pribadi" role="tabpanel">
            <table class="table table-bordered w-100">
                <tr><th>Nama Lengkap</th><td>{{ $teacher->nama_lengkap ?? '-' }}</td></tr>
                <tr><th>NIK</th><td>{{ $teacher->nik ?? '-' }}</td></tr>
                <tr><th>NUPTK</th><td>{{ $teacher->nuptk ?? '-' }}</td></tr>
                <tr><th>Tempat Lahir</th><td>{{ $teacher->tempat_lahir ?? '-' }}</td></tr>
                <tr><th>Tanggal Lahir</th><td>{{ $teacher->tanggal_lahir ?? '-' }}</td></tr>
                <tr><th>Jenis Kelamin</th><td>{{ $teacher->jenis_kelamin ?? '-' }}</td></tr>
                <tr><th>Agama</th><td>{{ $teacher->agama ?? '-' }}</td></tr>
                <tr><th>Alamat Lengkap</th><td>{{ $teacher->alamat ?? '-' }}</td></tr>
                <tr><th>Status Pernikahan</th><td>{{ $teacher->status_pernikahan ?? '-' }}</td></tr>
                <tr><th>Nomor HP/Kontak</th><td>{{ $teacher->telepon ?? '-' }}</td></tr>
                <tr><th>Status</th><td>{{ $teacher->status ?? '-' }}</td></tr>
                <tr><th>Email</th><td>{{ $teacher->email ?? '-' }}</td></tr>
                <tr><th>Foto</th><td>@if($teacher->foto)<a href="{{ asset('storage/'.$teacher->foto) }}" target="_blank">Lihat Foto</a>@else - @endif</td></tr>
            </table>
        </div>
        <!-- Data Kepegawaian -->
        <div class="tab-pane fade" id="kepegawaian" role="tabpanel">
            <table class="table table-bordered w-100">
                <tr><th>Status Kepegawaian</th><td>{{ $teacher->status_kepegawaian ?? '-' }}</td></tr>
                <tr><th>TMT</th><td>{{ $teacher->tmt ?? '-' }}</td></tr>
                <tr><th>SK Pengangkatan</th><td>@if($teacher->sk_pengangkatan)<a href="{{ asset('storage/'.$teacher->sk_pengangkatan) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>Nomor SK</th><td>{{ $teacher->nomor_sk ?? '-' }}</td></tr>
                <tr><th>Instansi Pengangkat</th><td>{{ $teacher->instansi_pengangkat ?? '-' }}</td></tr>
                <tr><th>Pangkat/Golongan</th><td>{{ $teacher->pangkat_golongan ?? '-' }}</td></tr>
                <tr><th>Gaji Pokok</th><td>{{ $teacher->gaji_pokok ?? '-' }}</td></tr>
            </table>
        </div>
        <!-- Status Khusus -->
        <div class="tab-pane fade" id="khusus" role="tabpanel">
            <table class="table table-bordered w-100">
                <tr><th>Sertifikasi Guru</th><td>{{ $teacher->sertifikasi_guru ?? '-' }}</td></tr>
                <tr><th>Nomor Sertifikat</th><td>{{ $teacher->nomor_sertifikat ?? '-' }}</td></tr>
                <tr><th>Mata Pelajaran Sertifikasi</th><td>{{ $teacher->mata_pelajaran_sertifikasi ?? '-' }}</td></tr>
                <tr><th>Tahun Sertifikasi</th><td>{{ $teacher->tahun_sertifikasi ?? '-' }}</td></tr>
                <tr><th>File Sertifikat</th><td>@if($teacher->file_sertifikat)<a href="{{ asset('storage/'.$teacher->file_sertifikat) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>Inpasing</th><td>{{ $teacher->inpasing ?? '-' }}</td></tr>
                <tr><th>Nomor Inpasing</th><td>{{ $teacher->nomor_inpasing ?? '-' }}</td></tr>
                <tr><th>Tahun Inpasing</th><td>{{ $teacher->tahun_inpasing ?? '-' }}</td></tr>
                <tr><th>SK Inpasing</th><td>@if($teacher->file_sk_inpasing)<a href="{{ asset('storage/'.$teacher->file_sk_inpasing) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>Tunjangan Khusus</th><td>{{ $teacher->tunjangan_khusus ?? '-' }}</td></tr>
            </table>
        </div>
        <!-- Data Akademik -->
        <div class="tab-pane fade" id="akademik" role="tabpanel">
            <table class="table table-bordered w-100">
                <tr><th>Lembaga</th><td>{{ $teacher->institution ? $teacher->institution->nama_lembaga : '-' }}</td></tr>
                <tr><th>Tahun Akademik</th><td>{{ $teacher->academicYear ? $teacher->academicYear->tahun_akademik . ' - ' . $teacher->academicYear->semester : '-' }}</td></tr>
                <tr><th>Jenjang</th><td>{{ $teacher->jenjang ?? '-' }}</td></tr>
                <tr><th>Tingkat</th><td>{{ $teacher->tingkat ?? '-' }}</td></tr>
                <tr><th>Kelas</th><td>{{ $teacher->kelas ?? '-' }}</td></tr>
                <tr><th>Pendidikan Terakhir</th><td>{{ $teacher->pendidikan_terakhir ?? '-' }}</td></tr>
                <tr><th>Nama Perguruan Tinggi</th><td>{{ $teacher->nama_pt ?? '-' }}</td></tr>
                <tr><th>Program Studi</th><td>{{ $teacher->program_studi ?? '-' }}</td></tr>
                <tr><th>Tahun Lulus</th><td>{{ $teacher->tahun_lulus ?? '-' }}</td></tr>
                <tr><th>File Ijazah</th><td>@if($teacher->file_ijazah)<a href="{{ asset('storage/'.$teacher->file_ijazah) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>Riwayat Pendidikan</th><td>{{ $teacher->riwayat_pendidikan ?? '-' }}</td></tr>
                <tr><th>Riwayat Mengajar</th><td>{{ $teacher->riwayat_mengajar ?? '-' }}</td></tr>
                <tr><th colspan="2">Mata Pelajaran Diampu (Rangkap)</th></tr>
                <tr><td colspan="2">
                    @php
                        $mapel_diampu = $teacher->mapel_diampu ? json_decode($teacher->mapel_diampu, true) : [];
                        $mapel_jenjang = $teacher->mapel_jenjang ? json_decode($teacher->mapel_jenjang, true) : [];
                        $mapel_tingkat = $teacher->mapel_tingkat ? json_decode($teacher->mapel_tingkat, true) : [];
                        $mapel_kelas = $teacher->mapel_kelas ? json_decode($teacher->mapel_kelas, true) : [];
                        $mapel_jam = $teacher->mapel_jam ? json_decode($teacher->mapel_jam, true) : [];
                    @endphp
                    <table class="table table-sm table-bordered mb-0">
                        <thead>
                            <tr>
                                <th style="width:22%">Mata Pelajaran</th>
                                <th style="width:18%">Jenjang</th>
                                <th style="width:15%">Tingkat</th>
                                <th style="width:20%">Kelas</th>
                                <th style="width:15%">Jam/Minggu</th>
                            </tr>
                        </thead>
                        <tbody>
                            @for($i=1;$i<=3;$i++)
                            @if(!empty($mapel_diampu[$i]) || !empty($mapel_jenjang[$i]) || !empty($mapel_tingkat[$i]) || !empty($mapel_kelas[$i]) || !empty($mapel_jam[$i]))
                            <tr>
                                <td>{{ $mapel_diampu[$i] ?? '-' }}</td>
                                <td>{{ $mapel_jenjang[$i] ?? '-' }}</td>
                                <td>{{ $mapel_tingkat[$i] ?? '-' }}</td>
                                <td>{{ $mapel_kelas[$i] ?? '-' }}</td>
                                <td>{{ $mapel_jam[$i] ?? '-' }}</td>
                            </tr>
                            @endif
                            @endfor
                        </tbody>
                    </table>
                </td></tr>
                <tr><th>Mengajar di Tempat Lain?</th><td>{{ $teacher->mengajar_tempat_lain ?? '-' }}</td></tr>
                @if(($teacher->mengajar_tempat_lain ?? '')=='Ya')
                <tr><th>Nama Lembaga (Lain)</th><td>{{ $teacher->nama_lembaga_lain ?? '-' }}</td></tr>
                <tr><th>Mata Pelajaran (Lain)</th><td>{{ $teacher->mapel_lain ?? '-' }}</td></tr>
                <tr><th>Jumlah Jam Mengajar (Lain)</th><td>{{ $teacher->jam_mengajar_lain ?? '-' }}</td></tr>
                @endif
            </table>
        </div>
        <!-- Berkas & Arsip Digital -->
        <div class="tab-pane fade" id="arsip" role="tabpanel">
            <table class="table table-bordered w-100">
                <tr><th>KTP</th><td>@if($teacher->file_ktp)<a href="{{ asset('storage/'.$teacher->file_ktp) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>KK</th><td>@if($teacher->file_kk)<a href="{{ asset('storage/'.$teacher->file_kk) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>Ijazah Terakhir</th><td>@if($teacher->file_ijazah_terakhir)<a href="{{ asset('storage/'.$teacher->file_ijazah_terakhir) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>Sertifikat Pelatihan</th><td>@if($teacher->file_sertifikat_pelatihan)<a href="{{ asset('storage/'.$teacher->file_sertifikat_pelatihan) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>SK Pengangkatan</th><td>@if($teacher->file_sk_pengangkatan)<a href="{{ asset('storage/'.$teacher->file_sk_pengangkatan) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>SK Penempatan</th><td>@if($teacher->file_sk_penempatan)<a href="{{ asset('storage/'.$teacher->file_sk_penempatan) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>SK Inpasing</th><td>@if($teacher->file_sk_inpasing)<a href="{{ asset('storage/'.$teacher->file_sk_inpasing) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>Sertifikat Sertifikasi</th><td>@if($teacher->file_sertifikat_sertifikasi)<a href="{{ asset('storage/'.$teacher->file_sertifikat_sertifikasi) }}" target="_blank">Download</a>@else - @endif</td></tr>
                <tr><th>Berkas Lainnya</th><td>@if($teacher->file_berkas_lain)<a href="{{ asset('storage/'.$teacher->file_berkas_lain) }}" target="_blank">Download</a>@else - @endif</td></tr>
            </table>
        </div>
    </div>
    <a href="{{ route('teacher.index') }}" class="btn btn-secondary btn-sm mt-3">Kembali</a>
</div>
@endsection

@push('styles')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<style>
    .nav-tabs .nav-link { font-size: 0.95rem; padding: 0.4rem 1.2rem; }
    .tab-content { background: #fff; border-radius: 0.3rem; box-shadow: 0 1px 4px rgba(0,0,0,0.03); padding: 1.2rem 1.5rem 0.5rem 1.5rem; margin-bottom: 1.5rem; }
    .table th, .table td { font-size: 0.95rem; }
</style>
@endpush

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var tabNav = document.getElementById('teacherTab');
    if (tabNav) {
        tabNav.querySelectorAll('.nav-link').forEach(function(tab) {
            tab.classList.remove('disabled');
            tab.removeAttribute('aria-disabled');
            tab.addEventListener('click', function (e) {
                var tabTrigger = new bootstrap.Tab(tab);
                tabTrigger.show();
            });
        });
    }
});
</script>
@endpush 