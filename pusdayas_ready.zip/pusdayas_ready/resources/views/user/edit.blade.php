@extends('layouts.app')
@section('content')
<div class="container">
    <h2 class="mb-4">Edit Akun</h2>
    <form method="POST" action="{{ route('user.update', $target->id) }}" enctype="multipart/form-data">
        @csrf @method('PUT')
        <div class="row mb-2">
            <div class="col-md-4">
                <label class="form-label">Nama</label>
                <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name', $target->name) }}" required>
                @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-4">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email', $target->email) }}" required>
                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-4">
                <label class="form-label">Role</label>
                @if(Auth::user()->role=='superadmin')
                <select name="role" class="form-control" id="role-select" required disabled>
                    <option value="superadmin" {{ $target->role=='superadmin'?'selected':'' }}>Superadmin</option>
                    <option value="admin_lembaga" {{ $target->role=='admin_lembaga'?'selected':'' }}>Admin Lembaga</option>
                </select>
                @else
                <input type="text" class="form-control" value="Admin Lembaga" readonly>
                @endif
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-md-4">
                <label class="form-label">Lembaga</label>
                @if(Auth::user()->role=='superadmin')
                <select name="institution_id" class="form-control" disabled>
                    <option value="">Pilih Lembaga</option>
                    @foreach($institutions as $inst)
                        <option value="{{ $inst->id }}" {{ $target->institution_id==$inst->id?'selected':'' }}>{{ $inst->nama_lembaga }}</option>
                    @endforeach
                </select>
                @else
                <input type="text" class="form-control" value="{{ $target->institution ? $target->institution->nama_lembaga : '-' }}" readonly>
                @endif
            </div>
            <div class="col-md-4">
                <label class="form-label">Status</label>
                <select name="status" class="form-control">
                    <option value="Aktif" {{ $target->status=='Aktif'?'selected':'' }}>Aktif</option>
                    <option value="Tidak Aktif" {{ $target->status=='Tidak Aktif'?'selected':'' }}>Tidak Aktif</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Foto Profil (opsional)</label>
                <input type="file" name="foto" class="form-control">
                @if($target->foto)
                <div class="mt-2"><img src="{{ asset('storage/'.$target->foto) }}" alt="foto" style="width:48px;height:48px;border-radius:50%;object-fit:cover;"></div>
                @endif
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="{{ route('user.index') }}" class="btn btn-secondary">Batal</a>
    </form>
</div>
@endsection 