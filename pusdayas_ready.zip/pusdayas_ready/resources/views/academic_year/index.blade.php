@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">
                        <i class="fas fa-calendar-alt text-primary"></i>
                        Manajemen Tahun Akademik
                    </h4>
                    <a href="{{ route('academic-year.create') }}" class="btn btn-primary">
                        <i class="fas fa-plus"></i> Tambah Tahun Akademik
                    </a>
                </div>
                <div class="card-body">
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle"></i> {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="fas fa-exclamation-circle"></i> {{ session('error') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif

                    <div class="table-responsive">
                        <table class="table table-hover table-bordered align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th width="5%">No</th>
                                    <th width="20%">Tahun Akademik</th>
                                    <th width="15%">Semester</th>
                                    <th width="15%">Periode</th>
                                    <th width="10%">Status</th>
                                    <th width="20%">Keterangan</th>
                                    <th width="15%">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($academicYears as $index => $academicYear)
                                <tr>
                                    <td class="text-center">{{ $index + 1 + ($academicYears->currentPage() - 1) * $academicYears->perPage() }}</td>
                                    <td>
                                        <strong>{{ $academicYear->tahun_akademik }}</strong>
                                    </td>
                                    <td>
                                        <span class="badge bg-{{ $academicYear->semester == 'Ganjil' ? 'primary' : 'success' }}">
                                            {{ $academicYear->semester }}
                                        </span>
                                    </td>
                                    <td>
                                        {{ \Carbon\Carbon::parse($academicYear->tanggal_mulai)->format('d/m/Y') }} - 
                                        {{ \Carbon\Carbon::parse($academicYear->tanggal_selesai)->format('d/m/Y') }}
                                    </td>
                                    <td class="text-center">
                                        @if($academicYear->status == 'aktif')
                                            <span class="badge bg-success">
                                                <i class="fas fa-check-circle"></i> Aktif
                                            </span>
                                        @else
                                            <span class="badge bg-secondary">
                                                <i class="fas fa-times-circle"></i> Nonaktif
                                            </span>
                                        @endif
                                    </td>
                                    <td>
                                        {{ $academicYear->keterangan ?: '-' }}
                                    </td>
                                    <td class="text-center">
                                        <div class="btn-group" role="group">
                                            <a href="{{ route('academic-year.show', $academicYear->id) }}" 
                                               class="btn btn-info btn-sm" 
                                               title="Detail">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="{{ route('academic-year.edit', $academicYear->id) }}" 
                                               class="btn btn-warning btn-sm" 
                                               title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="{{ route('academic-year.destroy', $academicYear->id) }}" 
                                                  method="POST" 
                                                  class="d-inline"
                                                  onsubmit="return confirm('Yakin ingin menghapus tahun akademik ini?')">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm" title="Hapus">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="7" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="fas fa-calendar-times fa-3x mb-3"></i>
                                            <p class="mb-0">Belum ada data tahun akademik</p>
                                        </div>
                                    </td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex justify-content-center">
                        {{ $academicYears->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 