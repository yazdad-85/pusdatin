<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $fillable = [
        'nama_lengkap','nik','tempat_lahir','tanggal_lahir','jenis_kelamin','agama','alamat','telepon','email','foto','status_pernikahan','pendidikan_terakhir',
        'employee_category_id','institution_id','unit_kerja','jabatan','tugas_tambahan',
        'status_pegawai','nomor_sk','tmt','masa_kerja','jenis_kontrak','status','keterangan_pensiun',
        'jenjang_pendidikan','nama_pt','tahun_lulus','file_ijazah','riwayat_pelatihan',
        'file_ktp','file_kk','file_ijazah_terakhir','file_sk_pengangkatan','file_sk_penugasan','file_sertifikat_pelatihan','file_perjanjian_kerja','file_dokumen_tambahan',
        'academic_year_id'
    ];
    protected $casts = [
        'riwayat_pelatihan' => 'array',
        'tmt' => 'date',
        'tanggal_lahir' => 'date',
        'tahun_lulus' => 'integer',
    ];
    public function category() {
        return $this->belongsTo(EmployeeCategory::class, 'employee_category_id');
    }
    public function institution() {
        return $this->belongsTo(Institution::class);
    }

    public function academicYear() {
        return $this->belongsTo(AcademicYear::class);
    }
}
