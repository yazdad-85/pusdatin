<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployeesTable extends Migration
{
    public function up()
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->bigIncrements('id');
            // Data Pribadi
            $table->string('nama_lengkap');
            $table->string('nik')->unique();
            $table->string('tempat_lahir')->nullable();
            $table->date('tanggal_lahir')->nullable();
            $table->enum('jenis_kelamin', ['Laki-laki', 'Perempuan'])->nullable();
            $table->string('agama')->nullable();
            $table->text('alamat')->nullable();
            $table->string('telepon')->nullable();
            $table->string('email')->nullable();
            $table->string('foto')->nullable();
            $table->string('status_pernikahan')->nullable();
            $table->string('pendidikan_terakhir')->nullable();
            // Kategori & Jabatan
            $table->unsignedBigInteger('employee_category_id')->nullable();
            $table->unsignedBigInteger('institution_id')->nullable();
            $table->string('unit_kerja')->nullable();
            $table->string('jabatan')->nullable();
            $table->string('tugas_tambahan')->nullable();
            // Data Kepegawaian
            $table->enum('status_pegawai', ['Tetap', 'Kontrak Yayasan'])->nullable();
            $table->string('nomor_sk')->nullable();
            $table->date('tmt')->nullable();
            $table->integer('masa_kerja')->nullable();
            $table->enum('jenis_kontrak', ['Tetap', 'Tidak Tetap'])->nullable();
            $table->enum('status', ['Aktif', 'Tidak Aktif'])->default('Aktif');
            $table->string('keterangan_pensiun')->nullable();
            // Data Akademik & Riwayat Pelatihan
            $table->string('jenjang_pendidikan')->nullable();
            $table->string('nama_pt')->nullable();
            $table->year('tahun_lulus')->nullable();
            $table->string('file_ijazah')->nullable();
            $table->json('riwayat_pelatihan')->nullable(); // array: nama, tahun, file
            // Berkas & Arsip Digital
            $table->string('file_ktp')->nullable();
            $table->string('file_kk')->nullable();
            $table->string('file_ijazah_terakhir')->nullable();
            $table->string('file_sk_pengangkatan')->nullable();
            $table->string('file_sk_penugasan')->nullable();
            $table->string('file_sertifikat_pelatihan')->nullable();
            $table->string('file_perjanjian_kerja')->nullable();
            $table->string('file_dokumen_tambahan')->nullable();
            $table->timestamps();
            // Relasi
            $table->foreign('employee_category_id')->references('id')->on('employee_categories')->onDelete('set null');
            $table->foreign('institution_id')->references('id')->on('institutions')->onDelete('set null');
        });
    }
    public function down()
    {
        Schema::dropIfExists('employees');
    }
} 