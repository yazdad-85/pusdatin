<?php

use Illuminate\Database\Seeder;
use App\User;
use Illuminate\Support\Facades\Hash;

class ResetSuperAdminPasswordSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Cari user super admin
        $superAdmin = User::where('role', 'superadmin')->first();
        
        if ($superAdmin) {
            // Reset password
            $superAdmin->update([
                'password' => Hash::make('superadmin123'),
                'status' => 'Aktif',
            ]);
            
            echo "Password super admin berhasil direset!\n";
            echo "Email: " . $superAdmin->email . "\n";
            echo "Password baru: superadmin123\n";
        } else {
            echo "Tidak ada user super admin ditemukan!\n";
            echo "Silakan jalankan CreateSuperAdminSeeder terlebih dahulu.\n";
        }
    }
} 