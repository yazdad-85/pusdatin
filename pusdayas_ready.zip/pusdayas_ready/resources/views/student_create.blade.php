@extends('layouts.app')
@section('content')
<div class="container">
    <h2 class="mb-4" style="font-size:1.3rem;">Tambah Siswa</h2>
    <div class="mb-4" style="display: flex; justify-content: flex-end;">
        <a href="{{ route('student.template') }}" class="btn btn-outline-info me-2">Download Template Excel</a>
        <button class="btn btn-success" type="button" data-bs-toggle="modal" data-bs-target="#importModal">Import Excel</button>
    </div>
    <!-- Modal Import Excel -->
    <div class="modal fade" id="importModal" tabindex="-1" aria-labelledby="importModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="importModalLabel" style="font-size:1rem;">Import Data Siswa dari Excel</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <form action="{{ route('student.import') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="modal-body">
              <input type="file" name="file" class="form-control form-control-xs" accept=".xlsx,.xls" required>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-success btn-sm">Import</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <ul class="nav nav-tabs mb-3 flex-nowrap overflow-auto" id="studentTab" role="tablist" style="white-space:nowrap; gap:0.5rem; font-size:0.95rem;">
      <li class="nav-item" role="presentation" style="flex:1 0 auto; min-width:140px;">
        <button class="nav-link active px-2 py-1" id="pribadi-tab" data-bs-toggle="tab" data-bs-target="#pribadi" type="button" role="tab" aria-controls="pribadi" aria-selected="true" style="font-size:0.95rem;">A. Data Pribadi</button>
      </li>
      <li class="nav-item" role="presentation" style="flex:1 0 auto; min-width:140px;">
        <button class="nav-link px-2 py-1" id="ortu-tab" data-bs-toggle="tab" data-bs-target="#ortu" type="button" role="tab" aria-controls="ortu" aria-selected="false" style="font-size:0.95rem;">B. Data Orang Tua/Wali</button>
      </li>
      <li class="nav-item" role="presentation" style="flex:1 0 auto; min-width:140px;">
        <button class="nav-link px-2 py-1" id="akademik-tab" data-bs-toggle="tab" data-bs-target="#akademik" type="button" role="tab" aria-controls="akademik" aria-selected="false" style="font-size:0.95rem;">C. Data Akademik</button>
      </li>
      <li class="nav-item" role="presentation" style="flex:1 0 auto; min-width:140px;">
        <button class="nav-link px-2 py-1" id="riwayat-tab" data-bs-toggle="tab" data-bs-target="#riwayat" type="button" role="tab" aria-controls="riwayat" aria-selected="false" style="font-size:0.95rem;">D. Riwayat & Arsip</button>
      </li>
      <li class="nav-item" role="presentation" style="flex:1 0 auto; min-width:140px;">
        <button class="nav-link px-2 py-1" id="beasiswa-tab" data-bs-toggle="tab" data-bs-target="#beasiswa" type="button" role="tab" aria-controls="beasiswa" aria-selected="false" style="font-size:0.95rem;">E. Data Beasiswa</button>
      </li>
    </ul>
    <div class="tab-content" id="studentTabContent">
      <!-- Data Pribadi -->
      <div class="tab-pane fade show active" id="pribadi" role="tabpanel" aria-labelledby="pribadi-tab">
        <form method="POST" action="{{ route('student.store') }}" enctype="multipart/form-data">
          @csrf
          <div class="row mb-2">
            <div class="col-md-6">
              <label class="form-label">Nama Lengkap</label>
              <input type="text" class="form-control form-control-xs" name="nama" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">NIS</label>
              <input type="text" class="form-control form-control-xs" name="nis" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">NISN</label>
              <input type="text" class="form-control form-control-xs" name="nisn" required>
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-md-4">
              <label class="form-label">Jenis Kelamin</label>
              <select class="form-control form-control-xs" name="jenis_kelamin" required>
                <option value="">Pilih</option>
                <option value="Laki-laki">Laki-laki</option>
                <option value="Perempuan">Perempuan</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Tempat Lahir</label>
              <input type="text" class="form-control form-control-xs" name="tempat_lahir" required>
            </div>
            <div class="col-md-4">
              <label class="form-label">Tanggal Lahir</label>
              <input type="date" class="form-control form-control-xs" name="tanggal_lahir" required>
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-md-4">
              <label class="form-label">Agama</label>
              <input type="text" class="form-control form-control-xs" name="agama" required>
            </div>
            <div class="col-md-8">
              <label class="form-label">Alamat Lengkap</label>
              <input type="text" class="form-control form-control-xs" name="alamat" required>
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-md-6">
              <label class="form-label">Nomor HP Siswa (opsional)</label>
              <input type="text" class="form-control form-control-xs" name="telepon">
            </div>
            <div class="col-md-6">
              <label class="form-label">Foto (upload)</label>
              <input type="file" class="form-control form-control-xs" name="foto">
            </div>
          </div>
          <div class="mt-3">
            <button type="submit" class="btn btn-primary btn-sm">Simpan Data Pribadi</button>
          </div>
        </form>
      </div>
      <!-- Data Orang Tua/Wali -->
      <div class="tab-pane fade" id="ortu" role="tabpanel" aria-labelledby="ortu-tab">
        <form method="POST" action="{{ route('student.store') }}">
          @csrf
          <div class="row mb-2">
            <div class="col-md-4">
              <label class="form-label">Nama Ayah</label>
              <input type="text" class="form-control form-control-xs" name="nama_ayah">
            </div>
            <div class="col-md-4">
              <label class="form-label">Pekerjaan Ayah</label>
              <input type="text" class="form-control form-control-xs" name="pekerjaan_ayah">
            </div>
            <div class="col-md-4">
              <label class="form-label">Pendidikan Ayah</label>
              <input type="text" class="form-control form-control-xs" name="pendidikan_ayah">
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-md-4">
              <label class="form-label">Nama Ibu</label>
              <input type="text" class="form-control form-control-xs" name="nama_ibu">
            </div>
            <div class="col-md-4">
              <label class="form-label">Pekerjaan Ibu</label>
              <input type="text" class="form-control form-control-xs" name="pekerjaan_ibu">
            </div>
            <div class="col-md-4">
              <label class="form-label">Pendidikan Ibu</label>
              <input type="text" class="form-control form-control-xs" name="pendidikan_ibu">
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-md-4">
              <label class="form-label">Nama Wali (jika ada)</label>
              <input type="text" class="form-control form-control-xs" name="nama_wali">
            </div>
            <div class="col-md-4">
              <label class="form-label">Pekerjaan Wali</label>
              <input type="text" class="form-control form-control-xs" name="pekerjaan_wali">
            </div>
            <div class="col-md-4">
              <label class="form-label">Nomor HP Orang Tua/Wali</label>
              <input type="text" class="form-control form-control-xs" name="telepon_wali">
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-md-4">
              <label class="form-label">Penghasilan Orang Tua/Wali</label>
              <select class="form-control form-control-xs" name="penghasilan">
                <option value="">Pilih</option>
                <option value="500.000 - 1.500.000">500.000 - 1.500.000</option>
                <option value="1.500.000 - 3.000.000">1.500.000 - 3.000.000</option>
                <option value="3.000.000 - 5.000.000">3.000.000 - 5.000.000</option>
                <option value=">5.000.000">&gt;5.000.000</option>
              </select>
            </div>
          </div>
          <div class="mt-3">
            <button type="submit" class="btn btn-primary btn-sm">Simpan Data Orang Tua/Wali</button>
          </div>
        </form>
      </div>
      <!-- Data Akademik -->
      <div class="tab-pane fade" id="akademik" role="tabpanel" aria-labelledby="akademik-tab">
        <form method="POST" action="{{ route('student.store') }}">
          @csrf
          <div class="row mb-2">
            <div class="col-md-4">
              <label class="form-label">Lembaga</label>
              <select class="form-control form-control-xs" name="institution_id" id="institution_id" required>
                <option value="">Pilih Lembaga</option>
                @foreach($institutions as $institution)
                  <option value="{{ $institution->id }}" data-jenjang="{{ $institution->jenis_lembaga }}">{{ $institution->nama_lembaga }}</option>
                @endforeach
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Tahun Akademik</label>
              <select class="form-control form-control-xs" name="academic_year_id" required>
                <option value="">Pilih Tahun Akademik</option>
                @foreach($academicYears as $academicYear)
                  <option value="{{ $academicYear->id }}">{{ $academicYear->tahun_akademik }} - {{ $academicYear->semester }}</option>
                @endforeach
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Jenjang</label>
              <select class="form-control form-control-xs" name="jenjang" id="jenjang-akademik" required>
                <option value="">Pilih</option>
                <option value="MI">MI</option>
                <option value="SD">SD</option>
                <option value="MTs">MTs</option>
                <option value="SMP">SMP</option>
                <option value="MA">MA</option>
                <option value="SMA">SMA</option>
                <option value="SMK">SMK</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Tingkat</label>
              <select class="form-control form-control-xs" name="tingkat" id="tingkat-akademik" required>
                <option value="">Pilih Tingkat</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Kelas Saat Ini</label>
              <input type="text" class="form-control form-control-xs" name="kelas">
            </div>
            <div class="col-md-4">
              <label class="form-label">Tahun Masuk</label>
              <input type="number" class="form-control form-control-xs" name="tahun_masuk" value="{{ old('tahun_masuk') }}">
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-md-4">
              <label class="form-label">Status</label>
              <select class="form-control form-control-xs" name="status">
                <option value="Aktif">Aktif</option>
                <option value="Lulus">Lulus</option>
                <option value="Pindah">Pindah</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Asal Sekolah (jika pindahan)</label>
              <input type="text" class="form-control form-control-xs" name="asal_sekolah">
            </div>
            <div class="col-md-4">
              <label class="form-label">Jurusan (untuk MA/SMA/SMK)</label>
              <input type="text" class="form-control form-control-xs" name="jurusan">
            </div>
          </div>
          <div class="mt-3">
            <button type="submit" class="btn btn-primary btn-sm">Simpan Data Akademik</button>
          </div>
        </form>
      </div>
      <!-- Riwayat dan Arsip -->
      <div class="tab-pane fade" id="riwayat" role="tabpanel" aria-labelledby="riwayat-tab">
        <form method="POST" action="{{ route('student.store') }}" enctype="multipart/form-data">
          @csrf
          <div class="row mb-2">
            <div class="col-md-6">
              <label class="form-label">Riwayat Pendidikan Sebelumnya</label>
              <input type="text" class="form-control form-control-xs" name="riwayat_pendidikan_sebelumnya" placeholder="Contoh: SMP Negeri 1 Gresik">
            </div>
            <div class="col-md-6">
              <label class="form-label">Riwayat Pendidikan</label>
              <input type="text" class="form-control form-control-xs" name="riwayat_pendidikan">
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-md-6">
              <label class="form-label">Prestasi Akademik / Non-akademik (opsional)</label>
              <input type="text" class="form-control form-control-xs" name="prestasi">
            </div>
            <div class="col-md-6">
              <label class="form-label">Lulus Ke Mana?</label>
              <input type="text" class="form-control form-control-xs" name="lulus_ke">
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-md-6">
              <label class="form-label">Akta Kelahiran</label>
              <input type="file" class="form-control form-control-xs" name="akta_kelahiran">
            </div>
            <div class="col-md-6">
              <label class="form-label">Kartu Keluarga</label>
              <input type="file" class="form-control form-control-xs" name="kartu_keluarga">
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-md-6">
              <label class="form-label">KIP/KKS/Kartu Perlindungan Sosial</label>
              <input type="file" class="form-control form-control-xs" name="kartu_kip">
            </div>
            <div class="col-md-6">
              <label class="form-label">Ijazah SMP/SD</label>
              <input type="file" class="form-control form-control-xs" name="ijazah">
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-md-6">
              <label class="form-label">Surat Pindah (jika ada)</label>
              <input type="file" class="form-control form-control-xs" name="surat_pindah">
            </div>
          </div>
          <div class="mt-3">
            <button type="submit" class="btn btn-primary btn-sm">Simpan Riwayat & Arsip</button>
          </div>
        </form>
      </div>
      <!-- Data Beasiswa -->
      <div class="tab-pane fade" id="beasiswa" role="tabpanel" aria-labelledby="beasiswa-tab">
        <form method="POST" action="{{ route('student.store') }}">
          @csrf
          <div class="row mb-2">
            <div class="col-md-4">
              <label class="form-label">Apakah menerima beasiswa?</label>
              <select class="form-control form-control-xs" name="beasiswa">
                <option value="Tidak">Tidak</option>
                <option value="Ya">Ya</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Jenis Beasiswa</label>
              <input type="text" class="form-control form-control-xs" name="jenis_beasiswa">
            </div>
            <div class="col-md-4">
              <label class="form-label">Periode Beasiswa</label>
              <input type="text" class="form-control form-control-xs" name="periode_beasiswa">
            </div>
          </div>
          <div class="row mb-2">
            <div class="col-md-12">
              <label class="form-label">Keterangan Tambahan</label>
              <input type="text" class="form-control form-control-xs" name="keterangan_beasiswa">
            </div>
          </div>
          <div class="mt-3">
            <button type="submit" class="btn btn-primary btn-sm">Simpan Data Beasiswa</button>
          </div>
        </form>
      </div>
    </div>
</div>
@endsection

@push('styles')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<style>
    .nav-tabs .nav-link {
        font-size: 0.95rem;
        padding: 0.4rem 1.2rem;
    }
    .tab-content {
        background: #fff;
        border-radius: 0.3rem;
        box-shadow: 0 1px 4px rgba(0,0,0,0.03);
        padding: 1.2rem 1.5rem 0.5rem 1.5rem;
        margin-bottom: 1.5rem;
    }
    .form-label {
        font-size: 0.85rem;
        font-weight: 400;
        margin-bottom: 0.2rem;
    }
    .form-control-xs {
        font-size: 0.85rem;
        padding: 0.2rem 0.5rem;
        border-radius: 0.2rem;
        height: 1.7rem;
    }
    .btn {
        font-size: 0.85rem;
        border-radius: 0.2rem;
        padding: 0.25rem 0.8rem;
    }
</style>
@endpush

@push('scripts')
<script>
function getTingkatOptions(jenjang) {
  if (jenjang === 'MI' || jenjang === 'SD') return [1,2,3,4,5,6];
  if (jenjang === 'MTs' || jenjang === 'SMP') return [7,8,9];
  if (jenjang === 'MA' || jenjang === 'SMA' || jenjang === 'SMK') return [10,11,12];
  return [];
}

document.addEventListener('DOMContentLoaded', function() {
  var tabNav = document.getElementById('studentTab');
  if (tabNav) {
    tabNav.querySelectorAll('.nav-link').forEach(function(tab) {
      tab.classList.remove('disabled');
      tab.removeAttribute('aria-disabled');
      tab.addEventListener('click', function (e) {
        var tabTrigger = new bootstrap.Tab(tab);
        tabTrigger.show();
      });
    });
  }

  var institutionSelect = document.getElementById('institution_id');
  var jenjangSelect = document.getElementById('jenjang-akademik');
  var tingkatSelect = document.getElementById('tingkat-akademik');

  function syncJenjangFromLembaga() {
    var selected = institutionSelect.options[institutionSelect.selectedIndex];
    var jenjang = selected.getAttribute('data-jenjang');
    if (jenjang) {
      jenjangSelect.value = jenjang;
      updateTingkatOptions(jenjang);
    }
  }
  function updateTingkatOptions(jenjang) {
    var tingkatList = getTingkatOptions(jenjang);
    tingkatSelect.innerHTML = '<option value="">Pilih Tingkat</option>';
    tingkatList.forEach(function(t) {
      tingkatSelect.innerHTML += `<option value="${t}">${t}</option>`;
    });
  }
  institutionSelect.addEventListener('change', syncJenjangFromLembaga);
  jenjangSelect.addEventListener('change', function() {
    updateTingkatOptions(jenjangSelect.value);
  });

  // Set tingkat saat create jika jenjang sudah terisi (misal reload karena validasi gagal)
  if (jenjangSelect.value) {
    updateTingkatOptions(jenjangSelect.value);
    tingkatSelect.value = "{{ old('tingkat') }}";
  }
});
</script>
@endpush