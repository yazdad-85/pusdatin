<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h1 class="mb-0">Data Guru</h1>
        <div class="d-flex gap-2 flex-wrap">
            <a href="<?php echo e(route('teacher.create')); ?>" class="btn btn-primary shadow-sm"><i class="fas fa-plus"></i> Tambah Guru</a>
            <a href="<?php echo e(route('teacher.template')); ?>" class="btn btn-outline-info"><i class="fas fa-file-excel"></i> Download Template Excel</a>
            <button class="btn btn-success" type="button" data-bs-toggle="modal" data-bs-target="#importModal"><i class="fas fa-file-import"></i> Import Excel</button>
        </div>
    </div>
    <!-- Modal Import Excel -->
    <div class="modal fade" id="importModal" tabindex="-1" aria-labelledby="importModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="importModalLabel" style="font-size:1rem;">Import Data Guru dari Excel</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <form action="<?php echo e(route('teacher.import')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
              <input type="file" name="file" class="form-control form-control-xs" accept=".xlsx,.xls" required>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-success btn-sm">Import</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <form method="GET" class="mb-3 row g-2 align-items-end flex-wrap">
        <div class="col-md-3">
            <label class="form-label mb-1">Lembaga</label>
            <select name="institution_id" class="form-control">
                <option value="">Semua Lembaga</option>
                <?php $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($institution->id); ?>" <?php echo e(request('institution_id') == $institution->id ? 'selected' : ''); ?>><?php echo e($institution->nama_lembaga); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label mb-1">Cari</label>
            <input type="text" name="q" class="form-control" placeholder="Cari nama, NIK, NUPTK, alamat..." value="<?php echo e(request('q')); ?>">
        </div>
        <div class="col-md-2">
            <button class="btn btn-primary w-100" type="submit"><i class="fas fa-search"></i> Filter</button>
        </div>
        <div class="col-md-1 d-flex align-items-end">
            <a href="<?php echo e(route('teacher.index')); ?>" class="btn btn-outline-secondary rounded-circle ms-2" title="Reset Filter" style="width:38px;height:38px;display:flex;align-items:center;justify-content:center;">
                <i class="fas fa-rotate-left"></i>
            </a>
        </div>
    </form>
    <div class="table-responsive">
        <table class="table table-hover table-bordered align-middle">
            <thead class="thead-dark">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>NIK</th>
                    <th>NUPTK</th>
                    <th>Lembaga</th>
                    <th>Telepon</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(($teachers->currentPage() - 1) * $teachers->perPage() + $loop->iteration); ?></td>
                    <td><?php echo e($teacher->nama_lengkap); ?></td>
                    <td><?php echo e($teacher->nik); ?></td>
                    <td><?php echo e($teacher->nuptk); ?></td>
                    <td><?php echo e($teacher->institution ? $teacher->institution->nama_lembaga : '-'); ?></td>
                    <td><?php echo e($teacher->telepon); ?></td>
                    <td><?php echo e($teacher->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('teacher.show', $teacher->id)); ?>" class="btn btn-sm btn-info" title="Detail"><i class="fas fa-eye" aria-label="Detail" alt="Detail"></i></a>
                        <a href="<?php echo e(route('teacher.edit', $teacher->id)); ?>" class="btn btn-sm btn-warning" title="Edit"><i class="fas fa-pen" aria-label="Edit" alt="Edit"></i></a>
                        <form action="<?php echo e(route('teacher.destroy', $teacher->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus guru ini?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fas fa-trash" aria-label="Hapus" alt="Hapus"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center">Belum ada data guru.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="d-flex justify-content-center mt-3">
        <?php echo e($teachers->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<style>
    .table-responsive { min-height: 200px; }
    @media (max-width: 768px) {
        .table-responsive { font-size: 0.95rem; }
        .btn, .form-control { font-size: 0.95rem; }
        h1 { font-size: 1.2rem; }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mbp19/Documents/YAZDAD/APLIKASI PLAN/pusdayas/resources/views/teacher.blade.php ENDPATH**/ ?>