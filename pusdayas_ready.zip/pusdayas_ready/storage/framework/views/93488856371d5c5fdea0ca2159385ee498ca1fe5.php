<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Data Karyawan</h2>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <div class="mb-3">
        <a href="<?php echo e(route('employee.create')); ?>" class="btn btn-primary shadow-sm"><i class="fas fa-plus"></i> Tambah Karyawan</a>
    </div>
    <div class="card mb-3" style="border-radius:0.5rem;box-shadow:0 1px 4px rgba(44,62,80,0.04);border:1px solid #e3e6f0;">
        <div class="card-body p-3">
            <form method="GET" class="row g-2 align-items-center flex-nowrap flex-wrap">
                <div class="col-auto" style="min-width:160px;">
                    <select name="employee_category_id" class="form-select form-select-sm">
                        <option value="">Semua Kategori</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>" <?php echo e(request('employee_category_id')==$cat->id?'selected':''); ?>><?php echo e($cat->nama_kategori); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-auto" style="min-width:160px;">
                    <select name="institution_id" class="form-select form-select-sm">
                        <option value="">Semua Lembaga</option>
                        <?php $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($inst->id); ?>" <?php echo e(request('institution_id')==$inst->id?'selected':''); ?>><?php echo e($inst->nama_lembaga); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-auto" style="min-width:180px;">
                    <input type="text" name="q" class="form-control form-control-sm" placeholder="Cari nama, NIK, telepon..." value="<?php echo e(request('q')); ?>">
                </div>
                <div class="col-auto">
                    <button class="btn btn-primary btn-sm" type="submit"><i class="fas fa-search"></i> Filter</button>
                    <a href="<?php echo e(route('employee')); ?>" class="btn btn-outline-secondary btn-sm" title="Reset"><i class="fas fa-rotate-left"></i></a>
                </div>
            </form>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-bordered align-middle">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>NIK</th>
                    <th>Kategori</th>
                    <th>Lembaga</th>
                    <th>Telepon</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(($employees->currentPage()-1)*$employees->perPage() + $loop->iteration); ?></td>
                    <td><?php echo e($emp->nama_lengkap); ?></td>
                    <td><?php echo e($emp->nik); ?></td>
                    <td><?php echo e($emp->category ? $emp->category->nama_kategori : '-'); ?></td>
                    <td><?php echo e($emp->institution ? $emp->institution->nama_lembaga : '-'); ?></td>
                    <td><?php echo e($emp->telepon); ?></td>
                    <td><?php echo e($emp->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('employee.show', $emp->id)); ?>" class="btn btn-sm btn-info" title="Detail"><i class="fas fa-eye"></i></a>
                        <a href="<?php echo e(route('employee.edit', $emp->id)); ?>" class="btn btn-sm btn-warning" title="Edit"><i class="fas fa-pen"></i></a>
                        <form action="<?php echo e(route('employee.destroy', $emp->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin hapus?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" type="submit" title="Hapus"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="text-center">Belum ada data karyawan.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="d-flex justify-content-center mt-3">
        <?php echo e($employees->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mbp19/Documents/YAZDAD/APLIKASI PLAN/pusdayas/resources/views/employee/index.blade.php ENDPATH**/ ?>