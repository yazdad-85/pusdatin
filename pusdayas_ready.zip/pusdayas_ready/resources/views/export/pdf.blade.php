@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Ekspor ke PDF</h1>
    <p>Halaman ini akan digunakan untuk ekspor data ke PDF.</p>
</div>
@endsection