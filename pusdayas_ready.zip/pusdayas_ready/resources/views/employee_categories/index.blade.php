@extends('layouts.app')
@section('content')
<div class="container">
    <h2 class="mb-4">Kategori Karyawan</h2>
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    <a href="{{ route('employee-categories.create') }}" class="btn btn-primary mb-3"><i class="fas fa-plus"></i> Tambah Kategori</a>
    <div class="table-responsive">
        <table class="table table-bordered align-middle">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Kategori</th>
                    <th>Keterangan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($categories as $cat)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $cat->nama_kategori }}</td>
                    <td>{{ $cat->keterangan }}</td>
                    <td>
                        <a href="{{ route('employee-categories.edit', $cat->id) }}" class="btn btn-sm btn-warning"><i class="fas fa-pen"></i></a>
                        <form action="{{ route('employee-categories.destroy', $cat->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin hapus?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr><td colspan="4" class="text-center">Belum ada kategori.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection 