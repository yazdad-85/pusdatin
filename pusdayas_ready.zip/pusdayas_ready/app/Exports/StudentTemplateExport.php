<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\WithHeadings;

class StudentTemplateExport implements WithHeadings
{
    public function headings(): array
    {
        return [
            'nama',
            'nisn',
            'tahun_masuk',
            'kelas',
            'telepon',
            'alamat',
        ];
    }
}
