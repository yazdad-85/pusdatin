@extends('layouts.app')
@section('content')
<div class="container">
    <h2 class="mb-4">Tambah Akun</h2>
    <form method="POST" action="{{ route('user.store') }}" enctype="multipart/form-data">
        @csrf
        <div class="row mb-2">
            <div class="col-md-4">
                <label class="form-label">Nama</label>
                <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" value="{{ old('name') }}" required>
                @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-4">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email') }}" required>
                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="col-md-4">
                <label class="form-label">Password (default)</label>
                <input type="text" class="form-control" value="123456" readonly>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-md-4">
                <label class="form-label">Role</label>
                <select name="role" class="form-control" id="role-select" required>
                    <option value="">Pilih Role</option>
                    <option value="superadmin" {{ old('role')=='superadmin'?'selected':'' }}>Superadmin</option>
                    <option value="admin_lembaga" {{ old('role')=='admin_lembaga'?'selected':'' }}>Admin Lembaga</option>
                </select>
            </div>
            <div class="col-md-4" id="lembaga-field">
                <label class="form-label">Lembaga</label>
                <select name="institution_id" class="form-control">
                    <option value="">Pilih Lembaga</option>
                    @foreach($institutions as $inst)
                        <option value="{{ $inst->id }}" {{ old('institution_id')==$inst->id?'selected':'' }}>{{ $inst->nama_lembaga }}</option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Status</label>
                <select name="status" class="form-control">
                    <option value="Aktif" {{ old('status')=='Aktif'?'selected':'' }}>Aktif</option>
                    <option value="Tidak Aktif" {{ old('status')=='Tidak Aktif'?'selected':'' }}>Tidak Aktif</option>
                </select>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-md-4">
                <label class="form-label">Foto Profil (opsional)</label>
                <input type="file" name="foto" class="form-control">
            </div>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="{{ route('user.index') }}" class="btn btn-secondary">Batal</a>
    </form>
</div>
@endsection
@push('scripts')
<script>
const roleSelect = document.getElementById('role-select');
const lembagaField = document.getElementById('lembaga-field');
const lembagaSelect = lembagaField.querySelector('select');

function toggleLembagaField() {
    if (roleSelect.value === 'admin_lembaga') {
        lembagaField.style.display = '';
        lembagaSelect.required = true;
    } else {
        lembagaField.style.display = 'none';
        lembagaSelect.required = false;
        lembagaSelect.value = '';
    }
}

roleSelect.addEventListener('change', toggleLembagaField);
document.addEventListener('DOMContentLoaded', toggleLembagaField);
</script>
@endpush 